import { render, h } from 'vue'
import Index from './index.vue'

const createDialog = (message, option = {}) => {
    // const mountNode = document.createElement('div')
    // const Instance = createApp(Index, {
    //     show: true,
    //     message,
    //     ...option,
    //     close: () => {
    //         Instance.unmount(mountNode)
    //         document.body.removeChild(mountNode)
    //     },
    // })
    // document.body.appendChild(mountNode)
    // Instance.mount(mountNode)
    const handleDestroy = () => {
        // 从 body 上移除组件
        render(null, document.body)
    }

    // 使用 h 函数创建 vnode
    const vnode = h(Index, {
        message,
        show: true,
        close: handleDestroy,
    })
    // 使用 render 函数将 vnode 渲染为真实DOM并挂载到 body 上
    render(vnode, document.body)
}

export default createDialog
