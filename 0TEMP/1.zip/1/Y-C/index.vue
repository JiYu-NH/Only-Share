<template>
    <van-popup v-model:show="showPopup" :style="{ padding: '64px' }" @close="close">
        <div class="temp">1</div>
        <div class="temp" @click="ccc">2</div>
        <div class="temp">3</div>
        {{ message }}
    </van-popup>
</template>

<script setup>
const props = defineProps({
    message: '',
    show: { type: Boolean },
    close: {
        type: Function,
        default: () => {
            console.log('3333')
        },
    },
    result: { type: Function },
})

const { show, close, result } = props
const showPopup = ref(false)

console.log(props)

const ccc = () => {
    console.log('ccc')
    // close()
    // handleClose()
    result(23)
}

const emit = defineEmits(['update:show'])

const handleClose = () => {
    console.log('????')
    emit('update:show', false)
}

showPopup.value = show
</script>

<style lang="scss" scoped>
.temp {
    border: 1px solid red;
    width: 100px;
    height: 100px;
}
</style>
