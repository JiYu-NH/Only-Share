<template>
    <div>
        <div class="header">
            <van-nav-bar title="城市列表" />
        </div>

        <div class="hot">
            <div class="title">热门城市</div>
            <div class="list">
                <van-button v-for="(city, index) in cities.slice(0, 6)" :key="index" class="item">
                    {{ city }}
                </van-button>
            </div>
        </div>
        <div>
            <!-- <van-index-bar @select="onSelect" ref="indexBarRef" :index-list="listindex" :sticky="true"> -->
            <van-index-bar :index-list="listindex" sticky>
                <van-cell-group v-for="group in groupedCities" :key="group.index">
                    <van-index-anchor :index="group.index" />
                    <van-cell v-for="city in group.cities" :key="city">{{ city }}</van-cell>
                </van-cell-group>
            </van-index-bar>
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import pinyin from 'pinyin'

const cities = [
    '江门',
    '济南',
    '吉安',
    '嘉兴',
    '金华',
    '酒泉',
    '北京',
    '成都',
    '上海',
    '西藏',
    '合肥',
    '天津',
    '青岛',
    '盐城',
    '阿坝',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
    '资阳',
]
const groupedCities = ref([])
const listindex = ref([])
// const indexBarRef = ref(null)
const groupCities = () => {
    const groupedCitiesMap = {}
    cities.forEach(city => {
        const index = getFirstLetter(city)
        if (!groupedCitiesMap[index]) {
            groupedCitiesMap[index] = []
        }
        groupedCitiesMap[index].push(city)
    })

    const sortedGroupedCities = Object.keys(groupedCitiesMap)
        .map(index => ({ index, cities: groupedCitiesMap[index] }))
        .sort((a, b) => a.index.localeCompare(b.index))

    groupedCities.value = sortedGroupedCities
    listindex.value = sortedGroupedCities.map(item => item.index)
    console.log(listindex.value)
}

// const onSelect = index => {
//     console.log('fffff')
//     return
//     if (indexBarRef.value) {
//         indexBarRef.value?.scrollTo(index)
//     }
// }

onMounted(() => {
    groupCities()
})

// 获取中文名称第一个字的拼音首字母
function getFirstLetter(chineseName) {
    // 将中文名称转换为拼音数组
    const pinyinArray = pinyin(chineseName, {
        style: pinyin.STYLE_FIRST_LETTER, // 使用首字母风格
    })

    // 获取第一个字的首字母
    const firstLetter = pinyinArray[0][0]
    return firstLetter.toUpperCase() // 将首字母转为大写
}
</script>

<style lang="scss" scoped>
:deep(.van-index-anchor) {
    background: #eee;
    color: #333;
}

.van-cell :deep(.van-cell__value) {
    text-align: left;
}

.hot {
    color: #333;
    padding: 0.15rem;
}

.hot .title {
    display: flex;
    align-items: center;
    margin-bottom: 0.1rem;
    font-size: 0.16rem;
}

.hot .list {
    width: 100%;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
}
.hot .list button {
    background: rgba(153, 153, 153, 0.103);
    border: none;
    outline: none;
    margin-bottom: 0.1rem;
    border-radius: 0.2rem;
    padding: 0.05rem 0.08rem;
}

.hot .list .item {
    width: 30%;
}
</style>
