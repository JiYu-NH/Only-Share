<template>
    <div class="box">
      <div class="mulu">目录</div>
      <div class="check_sort">
        <div class="chapter_check">
          <div class="num_num check">1-{{chapters.length}}</div>
        </div>
        <div class="sort" v-if="isAsc" @click="ChangeStatus">
          <div>正序</div>
          <div class="sort_icon">
            <img v-if="isAsc"
              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAAkCAYAAADCW8lNAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAANqADAAQAAAABAAAAJAAAAADpY+pGAAADkElEQVRYCe2ZS2hTQRSGm5hErBWkKGh10QYUrQpiX2RRrVQrgS4URCsiVHGnbnwgVJFq6wOqUkR3BRVqUWsX0m5Esa1ZJPRBRZCaVVfiIhiUlKhN0vhNcMokJOHe5mnJwDAzZ8458/9zZubOvbeoaIkmg+BVXV3dSXEwHA4bM8HTYDD8we/NiYmJV1r9V1VVrUf3EbYV4OqanJzs02or9Ay1tbWbQ6GQW4/RInW/Aa5Mqy3EHqPbKvQhFzQajevGxsa+i7aWhL5xmRbFNOjoGkdESo5JxEy0N8i2ltLkcrmmWYr3UT6UyaUIsBtaAKVLxyQcsfYvUIi8ZFJGDot8mJ0CsXyIgh4MhYjpma180C1ELB+ioAdDIWJ6ZisfdJdsxCJXKm7SV7nLHeWuqOuiGhOZKYvFctrpdP6Kkeekaaqrq9sUDAY7IJUqgK1zc3PDOOlJ1VE67I28i6VtORL1VCKeDj4LPkzc7N28ttxC0pLCUhThniotLe1d8JzjinxtuQIOkTOa2MtmonqYHCovLx/o7+8PJRkw8tkiSX9UF8HZjsBKcN7xpu5P2zKMGiVBA0J9DNw3Pz//YmZm5k1TU9PKBKq6xEzYZfx+Ir/G0GW325dnlRiDHpCIAdHo9XrfNjQ0rJayxZSQuo7dHbKM8A6Px1OZVWKQidqDtG2zs7PD9fX1axdJqgu7a6otq8JdUlIynVViVqv1HCCeqkAgt9Pv93+w2WyxH2sSPn+wMbCnHuLnouqL+hez2dw4MjLyO6vExGHBKXySWRWg1LQlEAg4ampqrKowXr29vd2IXg/kzqj9+PxYXFy8mwvCVyHPKjExIADCkBORuy3aMgG0gkPFwYWhUspiS/ajaWhoqBfdU2ofPp0sv70Oh8Mj5VknJgfmSG7jm2abbP8ry7gFjXIg7IqRF0HG4vP5XlIei+l7z/NzP8vvhyqXJ4kqy2qdvXIWsA8YVMXykyj4kG+UYGh/pr1NtkWJbJBIHRF7SpVH+mIFuWizZ1oBLfaN5isZpJ5D6gSkgvEw52wpqmDGx8ef0G4hB1R5knpPc3Pz8USkhF0k/CyHTuo5/9sCDjs4BojcCgEuXiJS3UzEecqEjwNhl3d/W1iWeyA2SF4Vh1gHh07UAzmOTkSUd39biMYoyPYREa8KGqCXtJISdnIp3qOe8b8tgH6mgk1WF88z3hW70VlD9O5CStePv2S+/+u+v+C0Uncf7WnEAAAAAElFTkSuQmCC"
              alt=""
            />
          </div>
        </div>
        <div class="sort" v-if="!isAsc" @click="ChangeStatus">
          <div>逆序</div>
          <div class="sort_icon">
            <img 
              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAAkCAYAAADCW8lNAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAANqADAAQAAAABAAAAJAAAAADpY+pGAAADnUlEQVRYCe1ZTWgTQRTObjZVY4KSGjx4MadaDyq0NckhtSpGAg0qGFtKiz0IXrwoFKygxJ8WpFEK4kHQevLn4M9JgtFisIe0TWpFsYpielEPRoNCLNQ2id+EDEyXbLNJk2moWVhm5703b77vvTezs4lGs0IvgfBqbGy8guZQOp0Wy8FTEIRZ3BfC4fAdtf6tVuvWZDI5CPsNwOWbmJi4q3YssRNsNlv93NzcVCGDirT9DnAb1YxFoHfCzg9CJmovimIPAuOj/XytmEqlkvmMSqRXNU9TU9MuzPecJUXmB86BhoaG82qx0FK8hAEHy1mK8N8XiUQeLAYMmXJB/xA41ijZoaQH4eekkp7KM8RoZzlbkDoMQmQd6VTguOl2u497vd6Ukm1FEEOJHUUmboGYVgmoXA77+waDoSsYDM7LdaRfll0w10RKMmTqBHS3ZaR+A/gXdgz679g+7NsTicQjl8u1ipXT52Ulho2iFwCvAQxbOT/Q34P7MwVJWuyK3Wgek2d6Yaw7Fos9cTqda6mMtstGDOXXj52unwLJtt90Ol0zXguvZHINMvbXaDQeQXuP1YHc3ng8/qylpWU9K+dODEAElB/JUi8LBICnkRXH6Ojoe1bOPpP11Nra2gnbIVYOn3aU5QuHw2Gmcq7EPB6PFqSGAISsK/b6gEw58AKOssJcz2QnhN0xkLvO6uFzx8zMzEu73b6JyLkSi0ajJFPdZGJ6AeBrvV7fHAqFvlJZtmXX3QIVxqTxLiPB8S1QaDRbcIoaRlmu5koMgDpZIOiHsGXvHhkZibFytc9Yiz2wvcjaI3N1KMt6rsQA4CkFAVLDJpNpH9bNLyorpgW5cxh3Gnc6O/6t2Wye4koM0ewAoQ5sEm0Wi2V/IBD4UwwZ+RiQuwy/23AfgM7m9/tnM3WMBd0HQTsmVv3mlzkn0Zqsra3tKhVYYAoCDzkQZy5JkraPjY29of18rQQHdXBwJp+hCv1mvE/IGrqhwrbsJqJWq1U8SBY6OwKk6tOkUL/F2EtI7yecAs6iPtuWUIpk7smamhrVX8jFgC1kjESMsfjI9xi5V8zFdVfkGbUqMZ7RLsVc1YyVIoo8fVQzxjPapZirmrFSRJGnjxWbscyRCif8ivu3ZanZlbL/tpxaqqPFxuNwrcF9FTbcDskV928LDRACMU2f8eUxj778xx6qztlK4+PjH7Nf0GX/tyUnAmUh+fhdB1IWkBoAzp/Kpv+R5h83Y0u+8tRrkgAAAABJRU5ErkJggg=="
              alt=""
            />
          </div>
        </div>
      </div>
      <div class="list">
        <div class="chapter" v-for="(chapter, index) in chapters" :key="index">
          <div class="cover">
            <van-image :src="chapter.coverUrl" fit="cover" />
            <div class="yd">
              <img :src="chapter.ydUrl" alt="" />
            </div>
          </div>
          <div class="info">
            <div class="title">{{ chapter.title }}</div>
            <div class="time">{{ chapter.date }}</div>
          </div>
          <div class="vip" v-if="chapter.isVip&&!chapter.isbuyed"><img src="https://mhw.p2lfie.com/assets/vip.8aeed138.png" alt="" data-v-50fa03c9=""></div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        isAsc:true,
        chapters: [
          {
            coverUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fsafe-img.xhscdn.com%2Fbw1%2Fb4a87154-18b6-4163-ac80-f4dc4bf58d09%3FimageView2%2F2%2Fw%2F1080%2Fformat%2Fjpg&refer=http%3A%2F%2Fsafe-img.xhscdn.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1698852552&t=579e4ac2396bab97ff284b1c50fff4f7',
            ydUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fsafe-img.xhscdn.com%2Fbw1%2Fb4a87154-18b6-4163-ac80-f4dc4bf58d09%3FimageView2%2F2%2Fw%2F1080%2Fformat%2Fjpg&refer=http%3A%2F%2Fsafe-img.xhscdn.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1698852552&t=579e4ac2396bab97ff284b1c50fff4f7',
            title: '第1话-',
            date: '2021-04-23',
            isVip:true,
            isbuyed:true
          },
          {
            coverUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fsafe-img.xhscdn.com%2Fbw1%2Fb4a87154-18b6-4163-ac80-f4dc4bf58d09%3FimageView2%2F2%2Fw%2F1080%2Fformat%2Fjpg&refer=http%3A%2F%2Fsafe-img.xhscdn.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1698852552&t=579e4ac2396bab97ff284b1c50fff4f7',
            ydUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fsafe-img.xhscdn.com%2Fbw1%2Fb4a87154-18b6-4163-ac80-f4dc4bf58d09%3FimageView2%2F2%2Fw%2F1080%2Fformat%2Fjpg&refer=http%3A%2F%2Fsafe-img.xhscdn.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1698852552&t=579e4ac2396bab97ff284b1c50fff4f7',
            title: '第2话-',
            date: '2021-04-23',
            isVip:true,
            isbuyed:false
          },
          {
            coverUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fsafe-img.xhscdn.com%2Fbw1%2Fb4a87154-18b6-4163-ac80-f4dc4bf58d09%3FimageView2%2F2%2Fw%2F1080%2Fformat%2Fjpg&refer=http%3A%2F%2Fsafe-img.xhscdn.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1698852552&t=579e4ac2396bab97ff284b1c50fff4f7',
            ydUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fsafe-img.xhscdn.com%2Fbw1%2Fb4a87154-18b6-4163-ac80-f4dc4bf58d09%3FimageView2%2F2%2Fw%2F1080%2Fformat%2Fjpg&refer=http%3A%2F%2Fsafe-img.xhscdn.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1698852552&t=579e4ac2396bab97ff284b1c50fff4f7',
            title: '第3话-',
            date: '2021-04-23',
            isVip:true,
            isbuyed:false
          },
          {
            coverUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fsafe-img.xhscdn.com%2Fbw1%2Fb4a87154-18b6-4163-ac80-f4dc4bf58d09%3FimageView2%2F2%2Fw%2F1080%2Fformat%2Fjpg&refer=http%3A%2F%2Fsafe-img.xhscdn.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1698852552&t=579e4ac2396bab97ff284b1c50fff4f7',
            ydUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fsafe-img.xhscdn.com%2Fbw1%2Fb4a87154-18b6-4163-ac80-f4dc4bf58d09%3FimageView2%2F2%2Fw%2F1080%2Fformat%2Fjpg&refer=http%3A%2F%2Fsafe-img.xhscdn.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1698852552&t=579e4ac2396bab97ff284b1c50fff4f7',
            title: '第4话-',
            date: '2021-04-23',
            isVip:true,
            isbuyed:false
          }
        ]
      };
    },
    methods:{
         ChangeStatus()
        {
          this.isAsc=!this.isAsc;
        }
    }
  };
  </script>
  
  <style lang="scss" scoped>
  .chapter_t {
    height: 0.51rem;
    line-height: 0.51rem;
    position: relative;
    background: #fff
}

.chapter_t .title {
    font-family: PingFangSC-Medium;
    font-size: 0.18rem;
    color: #333;
    letter-spacing: 0
}

.chapter_t .icon {
    position: absolute;
    left: 2.5%;
    top: 0;
    width: 0.16rem;
    height: 0.16rem
}

.box {
    position: relative;
    text-align: center;
}

.box .check_sort {
    width: 95%;
    margin: 0 auto;
    display: flex;
    justify-content: space-between
}

.box .check_sort .sort {
    display: flex;
    font-family: PingFangSC-Medium;
    font-size: 0.13rem;
    color: #333;
    letter-spacing: 0.0041rem;
    text-align: center;
    background: #fff
}

.box .check_sort .sort .sort_icon {
    width: 0.2rem;
    height: 0.12rem;
    margin: 0.02rem 0 0 0.02rem
}

.box .check_sort .sort .sort_icon img {
    width: 100%;
    height: 100%
}

.box .check_sort .chapter_check {
    flex: 1;
    font-family: PingFangSC-Regular;
    font-size: 0.12rem;
    color: #000;
    letter-spacing: 0;
    background: #fff;
    padding-bottom: 0.2rem;
    display: grid;
    grid-template-columns: repeat(4,1fr)
}

.box .check_sort .chapter_check .num_num {
    height: 0.2rem;
    padding: 0 0.05rem;
    background: #eeeeee;
    line-height: 0.2rem;
    border-radius: 0.1rem;
    margin-right: 0.1rem
}

.box .check_sort .chapter_check .check {
    background: #fbde0b
}

.box .mulu {
    height: 0.57rem;
    line-height: 0.57rem;
    font-family: PingFangSC-Medium;
    font-size: 0.18rem;
    color: #333;
    letter-spacing: 0
}

.box .list {
    width: 95%;
    margin: 0 auto;
    height: 5rem;
    overflow: auto
}

.box .list .chapter {
    display: flex;
    margin-bottom: 0.14rem;
    align-items: center;
    justify-content: space-between
}

.box .list .chapter .vip {
    width: 0.267rem;
    height: 0.217rem
}

.box .list .chapter .vip img {
    width: 100%;
    height: 100%
}

.box .list .chapter .cover {
    width: 1.2rem;
    height: 0.7rem;
    border-radius: 0.06rem;
    overflow: hidden;
    position: relative
}

.box .list .chapter .cover>div {
    width: 100%;
    height: 100%
}

.box .list .chapter .cover .yd {
    position: absolute;
    left: -0.01rem;
    top: -0.01rem;
    width: 0.3rem;
    height: 0.145rem
}

.box .list .chapter .cover .yd img {
    width: 100%;
    height: 100%
}

.box .list .chapter .info {
    text-align: left;
    flex: 1;
    padding-left: 0.115rem;
    font-family: PingFangSC-Medium;
    letter-spacing: 0
}

.box .list .chapter .info .title {
    font-size: 0.16rem;
    color: #000;
    width: 1.8rem;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis
}

.box .list .chapter .info .time {
    font-size: 0.13rem;
    color: #666;
    margin-top: 0.1rem
}

.btn_box {
    position: fixed;
    bottom: 0.3rem;
    left: 0;
    display: flex;
    justify-content: space-between;
    width: 100%
}

.btn_box .btn {
    width: 0.75rem;
    height: 0.4rem;
    line-height: 0.4rem;
    text-align: center;
    background: #fbde0b
}

.btn_box .last {
    border-radius: 0 0.2rem 0.2rem 0
}

.btn_box .next {
    border-radius: 0.2rem 0 0 0.2rem
}

.btn_box .dire {
    border-radius: 0.2rem
}

  </style>
  