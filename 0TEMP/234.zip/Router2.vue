<template>
    <div>
        <div class="home_t">
            <van-nav-bar title="签到" left-arrow right-text="我的记录" bind:click-left="onClickLeft"></van-nav-bar>

            <div class="info" data-v-9de6fb96="" data-v-5167d47d="">
                <div class="avater" data-v-9de6fb96="">
                    <img src="https://mhsign.7qbq7qw50.xyz/assets/default_avatar.c408299a.png" data-v-9de6fb96="" />
                </div>

                <div class="times" data-v-9de6fb96="">
                    <div class="yqd" data-v-9de6fb96="">已签到<span data-v-9de6fb96="">1</span>天</div>

                    <div class="tomm" data-v-9de6fb96="">明日签到可获得5积分</div>
                </div>
            </div>

            <div class="containers">
                <div class="day" data-v-5167d47d="">
                    <img
                        width="56px"
                        height="56px"
                        src="https://mhsign.7qbq7qw50.xyz/assets/30.8d5a999e.png"
                        alt=""
                        data-v-5167d47d=""
                    />
                </div>

                <div class="total" data-v-5167d47d="">
                    <div class="tt" data-v-5167d47d="">总积分</div>

                    <div class="ii" data-v-5167d47d="">
                        <img
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAA2CAYAAACMRWrdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAANqADAAQAAAABAAAANgAAAADzQy6kAAAMjUlEQVRoBd1aCVSVxxW+gKKiKEhxASpYqhiFiEaprRsYiEZjNOdESd16QmwJGuPWRmrl1CUnWo9SNQ3UaBNtbI3RisupVlFBAU1dMC6gCAqiVlxBFgFR6P3mcV/m/TxQcG3vOffNzJ3t+/7ZZ54NPVmx4eJ8WQNZu7H6sHqytmR1ZIUUsRayXmTNYE1jTWQ9zVrF+sIIyAxk/QvrdVaAa4giL8pAWSjzuQkqD2U9x9oQInXlQZkou8EEG5oxiCtdzNqL1ULsGzel7i+9Sr4+geTerjO1d/WmFg7O1LSpqSeWlRVR8d18unrjPF3JO0enMxLpxJm9dK+izKKc6sBRdj9iTbAWWZetvsQ6cmGfsb6uF9rcwYkCug9X6t81mJrYO+jRD/WX37tL36XvocMntistuVtgzLOTDZNZs40RtYXrQyyQC9nE6iKF2TduRm8GT6W3Bs+kZtUtInENdUu5ReN2LaVte5ZzK5bqxdziwNusibqxNv+jEgvnAj5lbYyCbG1s6dW+71Lo8DnUulV7mJ643L5zlTZs/5j2pnxJlVWVUn4Fe6awrhRDbe7DiNlxxuWs6AZKWju5UWTERvqx5ytieqpu1sVjtCh2FN0u+I9eD4bDVNYHulH3A3hdglYyk+rk1ZvmTf8XubftXFeeJxqHD9mv92g6k3VQJxfAlWBI7KitsrqIofvNl4wDAn5Os97foGY4sT0rF+N34E/G0PVbF+niFazjSkAuj/WYKWj5WxuxQE62nlXFg9S0sC/Jzq6RZe5nGELdfXqMpKvXz+vkBjOEJNYcIxRbo4HDmNIx+6mJAt1v0vhYK8mejwlYgKlagBFYgdlCrBHDwET/JfTvWRHfEBbdF0WABZiArVqAFZgtxEgsiGPV4ospHbPf05rOLVDUMwBMwAaM1QLMwG4WfYzZsPUbVvUpgvuF0eABE80JH8dTUVFORSW3KZ/Xppu3L5NDM0dqZKd6eoOLRYvd4iXgQu5xKQOnidUSABkRbDq/RgA7ipiP0x+rtTJzjtKxUzuVns9NlTqUa2trRx09uhO2XyN519K8WSuL+EcNYBGfNKervkN5h/NuQH5pMRDczKrG1luDf632fUhQX8m7cYGWrBpLf9sSRWmZSaqVUIatrS05OTmRo6MjlZQUK/uZrBRKOPQVf0A38nT3rW9VahuHzXN6VrLk7c6ePyEgLTaQ/YkwYEP7+SeZDdr7JRxaRyv//oHaqTdp0oRGjhxJQ4cOpZCQEGrXrh3Z2Jiqu3LlCiUlJdH8+fPpzJkzqJYixsVQCHd/o1Tcv0ffpsbR0VM7CC2EzQH2p25tO6mkd0sLKfx3nUnbOAdyxH4hhgOeKjXop+Npyi9WqUz1+TmdsZ/mLh9KlZUPFJHY2Fjy9vaus4iKigqaPXs2LVmyhFvUjmZP2kw9fbE0meTA4a/pq7g5dCv/spiU28rRlf4QmUxtXDxV+NO1v1QtX53oC3bfQ1cEOTBpzkqhb8whj3Y+8D6y5N/Jo6jo1wjHj7Fjx1JcXBy1bt36ofnt7OwoODiYcnNz6fjx43wu20ch/cOooPAad+dxtDU+mkrLCsnV1VWVGxoaSteuXaPcS9nc+rbUo1uIuY6UoxvF78GeJdhKoHO7woo1AgO6vrIz8c9UzLOev78/rV5tnpjqLKayspKqqqq4hStpxYoVlJKSQpmZmbQw5m2e6VKprLyE7O3tadq0aTRp0iQ+qDZV6UEyLCyMMi7821w+MAN79WEVXHyxEARKCpx863tIRGG7Dpi6blRUlAIg5VlzQeT+/fv04MED5cKPlps7d65Kns4TDkj16tWLEhMTacaMGYTxinTouph8IGXlRcrFDzADuyaBIIb5XwmO8/UVnHqLSm6Rp6cnjRgxotbsIAQyogCqE0SXRAuhZebNm0fbtm0jLy8vM3lJm5+fr+poYq9Gjrk+A/Zu6IrmAYU7Cl1wmt0av4wOpW6mazdz1KLa1rWj2qt16zyAXu4SpI7yyDN69Gj15fX88OtdDn49DJLojlAsBxMmTKCJEydShw4dzN1Uz4P0mFEhji0sx7ABuw+IeSEhBBcvIgWF1ylqaTBduYYLI5PgqJ596YTS3UmmsYTZDDJo0CBToupfHZA1v24Tgpj+YUdY4nUXHyAjA1eRfFnpZrnu6dg52gvETJ2WPbhNEonbtUSRcnNzo2XLlqk+X1xcTCdPnlQDPSEhgc6ePcsATIdYBwfTBQ6AAICA1f0CsjabxOsu0urh9PR0BdHL42WBqlwdOxscLYjJFRlSyoI3c+ZMGjVqlMqMHz8/PzX1wo9usWfPHgLJwsJCNR50INYICEjEPSxeT4sPVVRURELM27MnIJhFx85GRcwcqXucnUyXNEeOHNHNFn53d3caP348jRs3rkYX0gnqAOGXOGlVsRnDsOs2LAmYRFycPcw7DwtAWgCzonnexGWmSB9/0wyHxRaLolFQqcxUcHUFGAnDLyo2TNtQ3S5hpIFdTyO2/fv3KxiGqV3ZdOxsKLIghhtaETT1jzr0oPLycoqOjhazuWV0UPBL5bpfiIgreeBKawghPU4vS8pDuoMHDyocuJw1io6d4wpBLEcS4dpZl9FDZ6sgJo9z586pLykgxUXFAk4AwbVmkzwSr6eXcvQ0QgruiRMnCGuYQ9OW1KPr91spwWvAfhHETPMne3CXrkuA/3Be0YPp3r17NGXKFHOrCCC9YvihQkhaRE+j57PWlXWblCf5t2zZoqDhQqdx4yY6TOU3YM8AsTRJhQcCo0wMjVYL8+7du2nlypXmsWPtywpwPU78AlTCuiuE5KPocfDfvHmT9u3bp6ANHvgrI0QVNmBPA7FESYlXD+zQdcGKPmbEfGWKjIxU5ycBKS4qly+r28QuccawNbu1/GvXrlW9pnPHAN711HjgUZiBXZNEEMMN5A0YsaHFq4dRRoRMIz/eR5aWlqo1DH0dIAUoXOPX1gEKAXH1fEYbykG8tGJqaipt375dQRozYq4RmgoDc/XOHmFwOQ1iVaymnOzBptYoOPlOC1ujrryysrIoIiJCfUEAEJBCRAcq8ZJGwpJGd3U/0oEgNgCyzRoQ8A7vTQcZoamwATMIVIEY5K8mx0QMm1+jOLdqR7PCN1CjRvYUHx9Ps2bNMnc/ASwuvrYRKOLEJukQ1m3ih4uNwfTp09WOBstOxDjrl7bAaiCmuJh2sES5TGQMq0sFd0dbGzvy6xJo5MYrvju5telE3x6Po1OnTlFBQQH17dtXdRuQEUK6K3bdBuAS1v3o6snJyRQTE0Pr16+nsrIyfhX1oagPttbYzQu4jf9cyCdv8/DJZPtvEIdrAZFHvn7bdeBzvrT5UOXDRc2cOfxOxlcBAKnvAQFetk9CUA9j74f1MS0tTX0ofCx0QQhODUMGhNPYkfP5YqmFshl/6rp+04nBf5hVTTsh/d7j5v/MWJY5jBupmHXvM5n76lQbHh5Ow4YNU34hKGRKSkrUeMnOziZoTk4OYazm5eGxxFLauHhR/4BQdWMllzWWKb4Pxa6bTPHJuIdScpR/8QKDOcOixRAOYlULBq6PF0Um1fnAl5l9hFtuCl249B3yqsMijjnOzqbjD1oEM+idO3dUvLUfFyd38vHuQ128f6YOrh3culpLVsOGB8HIRf31185BnChBEuotJrYd7MFduJoFF/82pc4bYbTK7qRVtCMxli5fPStl1HAd+LYXd4I/bP8SebB6efjxXtSfWrb4QY20DzOgC360sK/+ELiT8wzV81kj1pET4KzigoR4slkwM/6RXlzwnHo5L4MHfbH6kg7NWirgri4dGnyNDQy6YL2KWhpCmTmAqOQW//ZmzTYFTb/WiCEmkHU3a2NWkoc/+J+3LPviXTpweL3AwEzzGmuiGMSV6V7C4uaw5zrrGzDgeRQviT19hzy3V020FG58NVKANpn1H/AYpTZiSHeM1ZUVM40ih/3YK36vN+heH2U0VDCmFqx4k46n7dKLwJS9QDfo/rqIIR26I8aaIocxlMxXyV079dNfFJHuqQlmv9//cQgfqcynK9QFUlNZ1dQOg1EeRgz/HMEsiQVnMKsdtjB7U9aoRzecsp/UP3K4bAtBK63ZFEmr1n9Id/n+vlowptD90FK1kkLa2iYPxBklkA2bWNVsicj/h78cgQcESwG6gVrnYID8r/9JzMTC9BvEzmLWGqc+vHq8CH/r08HW149ujI0zLkrQ35+kokyUXZ+hwsmfrKDygazYjWLtayhB5EUZKOuxCT12AQxCF5TnyxrI2o3Vh9WL1bFa2Xk2f3b+L7RqKkSogSQ7AAAAAElFTkSuQmCC"
                            alt=""
                            data-v-5167d47d=""
                        />
                    </div>

                    <div class="nn" data-v-5167d47d="">5</div>
                </div>
            </div>

            <van-calendar
                title="asd1"
                :poppable="false"
                :show-confirm="false"
                :show="currentMonth"
                :show-months="1"
                :show-title="false"
                :show-subtitle="false"
                :style="{ height: '500px', background: 'transparent', 'margin-top': '60px' }"
                :show-mark="false"
            />
        </div>

        <div class="btnsign" data-v-11a5c269="" data-v-5167d47d="">
            <img src="https://mhsign.7qbq7qw50.xyz/assets/btn_n.b5efb62f.png" alt="" data-v-11a5c269="" />

            <div class="text" data-v-11a5c269=""><span data-v-11a5c269="">签到成功</span></div>
        </div>

        <div>
            <van-tabs v-model="activeTab" type="line">
                <van-tab title="0000" v-model="dynamicList">
                    <template #title>
                        <img
                            width="117px"
                            height="29px"
                            src="https://mhsign.7qbq7qw50.xyz/assets/dh_y.e6ba675a.png"
                            alt="Tab Image"
                        />
                    </template>
                    <van-empty
                        v-if="dynamicList.length <= 0"
                        class="custom-image"
                        image="https://mhw.p2lfie.com/assets/ic_none.3df97c45.png"
                        description="空空的什么都没有"
                        title=""
                    />
                    <div v-else>
                        <div v-for="item in myCircle" :key="item.id">
                            <div class="circle">
                                <div class="cover">
                                    <van-image :src="item.icon" fit="cover" alt="Image Alt Text" />
                                </div>

                                <div class="many" data-v-56721eda="">
                                    <div class="total" data-v-56721eda="">
                                        <div class="tt" data-v-56721eda="">每日首充</div>

                                        <div class="ii" data-v-56721eda="">
                                            <img
                                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAA2CAYAAACMRWrdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAANqADAAQAAAABAAAANgAAAADzQy6kAAAMjUlEQVRoBd1aCVSVxxW+gKKiKEhxASpYqhiFiEaprRsYiEZjNOdESd16QmwJGuPWRmrl1CUnWo9SNQ3UaBNtbI3RisupVlFBAU1dMC6gCAqiVlxBFgFR6P3mcV/m/TxQcG3vOffNzJ3t+/7ZZ54NPVmx4eJ8WQNZu7H6sHqytmR1ZIUUsRayXmTNYE1jTWQ9zVrF+sIIyAxk/QvrdVaAa4giL8pAWSjzuQkqD2U9x9oQInXlQZkou8EEG5oxiCtdzNqL1ULsGzel7i+9Sr4+geTerjO1d/WmFg7O1LSpqSeWlRVR8d18unrjPF3JO0enMxLpxJm9dK+izKKc6sBRdj9iTbAWWZetvsQ6cmGfsb6uF9rcwYkCug9X6t81mJrYO+jRD/WX37tL36XvocMntistuVtgzLOTDZNZs40RtYXrQyyQC9nE6iKF2TduRm8GT6W3Bs+kZtUtInENdUu5ReN2LaVte5ZzK5bqxdziwNusibqxNv+jEgvnAj5lbYyCbG1s6dW+71Lo8DnUulV7mJ643L5zlTZs/5j2pnxJlVWVUn4Fe6awrhRDbe7DiNlxxuWs6AZKWju5UWTERvqx5ytieqpu1sVjtCh2FN0u+I9eD4bDVNYHulH3A3hdglYyk+rk1ZvmTf8XubftXFeeJxqHD9mv92g6k3VQJxfAlWBI7KitsrqIofvNl4wDAn5Os97foGY4sT0rF+N34E/G0PVbF+niFazjSkAuj/WYKWj5WxuxQE62nlXFg9S0sC/Jzq6RZe5nGELdfXqMpKvXz+vkBjOEJNYcIxRbo4HDmNIx+6mJAt1v0vhYK8mejwlYgKlagBFYgdlCrBHDwET/JfTvWRHfEBbdF0WABZiArVqAFZgtxEgsiGPV4ospHbPf05rOLVDUMwBMwAaM1QLMwG4WfYzZsPUbVvUpgvuF0eABE80JH8dTUVFORSW3KZ/Xppu3L5NDM0dqZKd6eoOLRYvd4iXgQu5xKQOnidUSABkRbDq/RgA7ipiP0x+rtTJzjtKxUzuVns9NlTqUa2trRx09uhO2XyN519K8WSuL+EcNYBGfNKervkN5h/NuQH5pMRDczKrG1luDf632fUhQX8m7cYGWrBpLf9sSRWmZSaqVUIatrS05OTmRo6MjlZQUK/uZrBRKOPQVf0A38nT3rW9VahuHzXN6VrLk7c6ePyEgLTaQ/YkwYEP7+SeZDdr7JRxaRyv//oHaqTdp0oRGjhxJQ4cOpZCQEGrXrh3Z2Jiqu3LlCiUlJdH8+fPpzJkzqJYixsVQCHd/o1Tcv0ffpsbR0VM7CC2EzQH2p25tO6mkd0sLKfx3nUnbOAdyxH4hhgOeKjXop+Npyi9WqUz1+TmdsZ/mLh9KlZUPFJHY2Fjy9vaus4iKigqaPXs2LVmyhFvUjmZP2kw9fbE0meTA4a/pq7g5dCv/spiU28rRlf4QmUxtXDxV+NO1v1QtX53oC3bfQ1cEOTBpzkqhb8whj3Y+8D6y5N/Jo6jo1wjHj7Fjx1JcXBy1bt36ofnt7OwoODiYcnNz6fjx43wu20ch/cOooPAad+dxtDU+mkrLCsnV1VWVGxoaSteuXaPcS9nc+rbUo1uIuY6UoxvF78GeJdhKoHO7woo1AgO6vrIz8c9UzLOev78/rV5tnpjqLKayspKqqqq4hStpxYoVlJKSQpmZmbQw5m2e6VKprLyE7O3tadq0aTRp0iQ+qDZV6UEyLCyMMi7821w+MAN79WEVXHyxEARKCpx863tIRGG7Dpi6blRUlAIg5VlzQeT+/fv04MED5cKPlps7d65Kns4TDkj16tWLEhMTacaMGYTxinTouph8IGXlRcrFDzADuyaBIIb5XwmO8/UVnHqLSm6Rp6cnjRgxotbsIAQyogCqE0SXRAuhZebNm0fbtm0jLy8vM3lJm5+fr+poYq9Gjrk+A/Zu6IrmAYU7Cl1wmt0av4wOpW6mazdz1KLa1rWj2qt16zyAXu4SpI7yyDN69Gj15fX88OtdDn49DJLojlAsBxMmTKCJEydShw4dzN1Uz4P0mFEhji0sx7ABuw+IeSEhBBcvIgWF1ylqaTBduYYLI5PgqJ596YTS3UmmsYTZDDJo0CBToupfHZA1v24Tgpj+YUdY4nUXHyAjA1eRfFnpZrnu6dg52gvETJ2WPbhNEonbtUSRcnNzo2XLlqk+X1xcTCdPnlQDPSEhgc6ePcsATIdYBwfTBQ6AAICA1f0CsjabxOsu0urh9PR0BdHL42WBqlwdOxscLYjJFRlSyoI3c+ZMGjVqlMqMHz8/PzX1wo9usWfPHgLJwsJCNR50INYICEjEPSxeT4sPVVRURELM27MnIJhFx85GRcwcqXucnUyXNEeOHNHNFn53d3caP348jRs3rkYX0gnqAOGXOGlVsRnDsOs2LAmYRFycPcw7DwtAWgCzonnexGWmSB9/0wyHxRaLolFQqcxUcHUFGAnDLyo2TNtQ3S5hpIFdTyO2/fv3KxiGqV3ZdOxsKLIghhtaETT1jzr0oPLycoqOjhazuWV0UPBL5bpfiIgreeBKawghPU4vS8pDuoMHDyocuJw1io6d4wpBLEcS4dpZl9FDZ6sgJo9z586pLykgxUXFAk4AwbVmkzwSr6eXcvQ0QgruiRMnCGuYQ9OW1KPr91spwWvAfhHETPMne3CXrkuA/3Be0YPp3r17NGXKFHOrCCC9YvihQkhaRE+j57PWlXWblCf5t2zZoqDhQqdx4yY6TOU3YM8AsTRJhQcCo0wMjVYL8+7du2nlypXmsWPtywpwPU78AlTCuiuE5KPocfDfvHmT9u3bp6ANHvgrI0QVNmBPA7FESYlXD+zQdcGKPmbEfGWKjIxU5ycBKS4qly+r28QuccawNbu1/GvXrlW9pnPHAN711HjgUZiBXZNEEMMN5A0YsaHFq4dRRoRMIz/eR5aWlqo1DH0dIAUoXOPX1gEKAXH1fEYbykG8tGJqaipt375dQRozYq4RmgoDc/XOHmFwOQ1iVaymnOzBptYoOPlOC1ujrryysrIoIiJCfUEAEJBCRAcq8ZJGwpJGd3U/0oEgNgCyzRoQ8A7vTQcZoamwATMIVIEY5K8mx0QMm1+jOLdqR7PCN1CjRvYUHx9Ps2bNMnc/ASwuvrYRKOLEJukQ1m3ih4uNwfTp09WOBstOxDjrl7bAaiCmuJh2sES5TGQMq0sFd0dbGzvy6xJo5MYrvju5telE3x6Po1OnTlFBQQH17dtXdRuQEUK6K3bdBuAS1v3o6snJyRQTE0Pr16+nsrIyfhX1oagPttbYzQu4jf9cyCdv8/DJZPtvEIdrAZFHvn7bdeBzvrT5UOXDRc2cOfxOxlcBAKnvAQFetk9CUA9j74f1MS0tTX0ofCx0QQhODUMGhNPYkfP5YqmFshl/6rp+04nBf5hVTTsh/d7j5v/MWJY5jBupmHXvM5n76lQbHh5Ow4YNU34hKGRKSkrUeMnOziZoTk4OYazm5eGxxFLauHhR/4BQdWMllzWWKb4Pxa6bTPHJuIdScpR/8QKDOcOixRAOYlULBq6PF0Um1fnAl5l9hFtuCl249B3yqsMijjnOzqbjD1oEM+idO3dUvLUfFyd38vHuQ128f6YOrh3culpLVsOGB8HIRf31185BnChBEuotJrYd7MFduJoFF/82pc4bYbTK7qRVtCMxli5fPStl1HAd+LYXd4I/bP8SebB6efjxXtSfWrb4QY20DzOgC360sK/+ELiT8wzV81kj1pET4KzigoR4slkwM/6RXlzwnHo5L4MHfbH6kg7NWirgri4dGnyNDQy6YL2KWhpCmTmAqOQW//ZmzTYFTb/WiCEmkHU3a2NWkoc/+J+3LPviXTpweL3AwEzzGmuiGMSV6V7C4uaw5zrrGzDgeRQviT19hzy3V020FG58NVKANpn1H/AYpTZiSHeM1ZUVM40ih/3YK36vN+heH2U0VDCmFqx4k46n7dKLwJS9QDfo/rqIIR26I8aaIocxlMxXyV079dNfFJHuqQlmv9//cQgfqcynK9QFUlNZ1dQOg1EeRgz/HMEsiQVnMKsdtjB7U9aoRzecsp/UP3K4bAtBK63ZFEmr1n9Id/n+vlowptD90FK1kkLa2iYPxBklkA2bWNVsicj/h78cgQcESwG6gVrnYID8r/9JzMTC9BvEzmLWGqc+vHq8CH/r08HW149ujI0zLkrQ35+kokyUXZ+hwsmfrKDygazYjWLtayhB5EUZKOuxCT12AQxCF5TnyxrI2o3Vh9WL1bFa2Xk2f3b+L7RqKkSogSQ7AAAAAElFTkSuQmCC"
                                                alt=""
                                                data-v-56721eda=""
                                            />
                                        </div>

                                        <div class="nn" data-v-56721eda="">20</div>
                                    </div>
                                    <div class="progress" data-v-56721eda="">
                                        <div class="jd" data-v-56721eda="">
                                            <div
                                                class="pre"
                                                data-v-56721eda=""
                                                :style="{ width: 50 + '%', height: 100 + '%' }"
                                            ></div>
                                        </div>

                                        <div class="bi" data-v-56721eda="">0/1</div>
                                    </div>
                                </div>

                                <div class="btn" @click="Quit">去完成</div>
                            </div>
                        </div>
                    </div>
                </van-tab>

                <van-tab :title="renderTabTitle1(activeTab)" v-model="myCircle">
                    <van-empty
                        v-if="myCircle.length <= 0"
                        image="https://mhw.p2lfie.com/assets/ic_none.3df97c45.png"
                        description="空空的什么都没有"
                        title=""
                    />

                    <div v-else>
                        <div v-for="item in myCircle" :key="item.id">
                            <div class="circle">
                                <div class="cover">
                                    <van-image :src="item.icon" fit="cover" alt="Image Alt Text" />
                                </div>

                                <div class="many" data-v-56721eda="">
                                    <div class="total" data-v-56721eda="">
                                        <div class="tt" data-v-56721eda="">每日首充</div>

                                        <div class="ii" data-v-56721eda="">
                                            <img
                                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAA2CAYAAACMRWrdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAANqADAAQAAAABAAAANgAAAADzQy6kAAAMjUlEQVRoBd1aCVSVxxW+gKKiKEhxASpYqhiFiEaprRsYiEZjNOdESd16QmwJGuPWRmrl1CUnWo9SNQ3UaBNtbI3RisupVlFBAU1dMC6gCAqiVlxBFgFR6P3mcV/m/TxQcG3vOffNzJ3t+/7ZZ54NPVmx4eJ8WQNZu7H6sHqytmR1ZIUUsRayXmTNYE1jTWQ9zVrF+sIIyAxk/QvrdVaAa4giL8pAWSjzuQkqD2U9x9oQInXlQZkou8EEG5oxiCtdzNqL1ULsGzel7i+9Sr4+geTerjO1d/WmFg7O1LSpqSeWlRVR8d18unrjPF3JO0enMxLpxJm9dK+izKKc6sBRdj9iTbAWWZetvsQ6cmGfsb6uF9rcwYkCug9X6t81mJrYO+jRD/WX37tL36XvocMntistuVtgzLOTDZNZs40RtYXrQyyQC9nE6iKF2TduRm8GT6W3Bs+kZtUtInENdUu5ReN2LaVte5ZzK5bqxdziwNusibqxNv+jEgvnAj5lbYyCbG1s6dW+71Lo8DnUulV7mJ643L5zlTZs/5j2pnxJlVWVUn4Fe6awrhRDbe7DiNlxxuWs6AZKWju5UWTERvqx5ytieqpu1sVjtCh2FN0u+I9eD4bDVNYHulH3A3hdglYyk+rk1ZvmTf8XubftXFeeJxqHD9mv92g6k3VQJxfAlWBI7KitsrqIofvNl4wDAn5Os97foGY4sT0rF+N34E/G0PVbF+niFazjSkAuj/WYKWj5WxuxQE62nlXFg9S0sC/Jzq6RZe5nGELdfXqMpKvXz+vkBjOEJNYcIxRbo4HDmNIx+6mJAt1v0vhYK8mejwlYgKlagBFYgdlCrBHDwET/JfTvWRHfEBbdF0WABZiArVqAFZgtxEgsiGPV4ospHbPf05rOLVDUMwBMwAaM1QLMwG4WfYzZsPUbVvUpgvuF0eABE80JH8dTUVFORSW3KZ/Xppu3L5NDM0dqZKd6eoOLRYvd4iXgQu5xKQOnidUSABkRbDq/RgA7ipiP0x+rtTJzjtKxUzuVns9NlTqUa2trRx09uhO2XyN519K8WSuL+EcNYBGfNKervkN5h/NuQH5pMRDczKrG1luDf632fUhQX8m7cYGWrBpLf9sSRWmZSaqVUIatrS05OTmRo6MjlZQUK/uZrBRKOPQVf0A38nT3rW9VahuHzXN6VrLk7c6ePyEgLTaQ/YkwYEP7+SeZDdr7JRxaRyv//oHaqTdp0oRGjhxJQ4cOpZCQEGrXrh3Z2Jiqu3LlCiUlJdH8+fPpzJkzqJYixsVQCHd/o1Tcv0ffpsbR0VM7CC2EzQH2p25tO6mkd0sLKfx3nUnbOAdyxH4hhgOeKjXop+Npyi9WqUz1+TmdsZ/mLh9KlZUPFJHY2Fjy9vaus4iKigqaPXs2LVmyhFvUjmZP2kw9fbE0meTA4a/pq7g5dCv/spiU28rRlf4QmUxtXDxV+NO1v1QtX53oC3bfQ1cEOTBpzkqhb8whj3Y+8D6y5N/Jo6jo1wjHj7Fjx1JcXBy1bt36ofnt7OwoODiYcnNz6fjx43wu20ch/cOooPAad+dxtDU+mkrLCsnV1VWVGxoaSteuXaPcS9nc+rbUo1uIuY6UoxvF78GeJdhKoHO7woo1AgO6vrIz8c9UzLOev78/rV5tnpjqLKayspKqqqq4hStpxYoVlJKSQpmZmbQw5m2e6VKprLyE7O3tadq0aTRp0iQ+qDZV6UEyLCyMMi7821w+MAN79WEVXHyxEARKCpx863tIRGG7Dpi6blRUlAIg5VlzQeT+/fv04MED5cKPlps7d65Kns4TDkj16tWLEhMTacaMGYTxinTouph8IGXlRcrFDzADuyaBIIb5XwmO8/UVnHqLSm6Rp6cnjRgxotbsIAQyogCqE0SXRAuhZebNm0fbtm0jLy8vM3lJm5+fr+poYq9Gjrk+A/Zu6IrmAYU7Cl1wmt0av4wOpW6mazdz1KLa1rWj2qt16zyAXu4SpI7yyDN69Gj15fX88OtdDn49DJLojlAsBxMmTKCJEydShw4dzN1Uz4P0mFEhji0sx7ABuw+IeSEhBBcvIgWF1ylqaTBduYYLI5PgqJ596YTS3UmmsYTZDDJo0CBToupfHZA1v24Tgpj+YUdY4nUXHyAjA1eRfFnpZrnu6dg52gvETJ2WPbhNEonbtUSRcnNzo2XLlqk+X1xcTCdPnlQDPSEhgc6ePcsATIdYBwfTBQ6AAICA1f0CsjabxOsu0urh9PR0BdHL42WBqlwdOxscLYjJFRlSyoI3c+ZMGjVqlMqMHz8/PzX1wo9usWfPHgLJwsJCNR50INYICEjEPSxeT4sPVVRURELM27MnIJhFx85GRcwcqXucnUyXNEeOHNHNFn53d3caP348jRs3rkYX0gnqAOGXOGlVsRnDsOs2LAmYRFycPcw7DwtAWgCzonnexGWmSB9/0wyHxRaLolFQqcxUcHUFGAnDLyo2TNtQ3S5hpIFdTyO2/fv3KxiGqV3ZdOxsKLIghhtaETT1jzr0oPLycoqOjhazuWV0UPBL5bpfiIgreeBKawghPU4vS8pDuoMHDyocuJw1io6d4wpBLEcS4dpZl9FDZ6sgJo9z586pLykgxUXFAk4AwbVmkzwSr6eXcvQ0QgruiRMnCGuYQ9OW1KPr91spwWvAfhHETPMne3CXrkuA/3Be0YPp3r17NGXKFHOrCCC9YvihQkhaRE+j57PWlXWblCf5t2zZoqDhQqdx4yY6TOU3YM8AsTRJhQcCo0wMjVYL8+7du2nlypXmsWPtywpwPU78AlTCuiuE5KPocfDfvHmT9u3bp6ANHvgrI0QVNmBPA7FESYlXD+zQdcGKPmbEfGWKjIxU5ycBKS4qly+r28QuccawNbu1/GvXrlW9pnPHAN711HjgUZiBXZNEEMMN5A0YsaHFq4dRRoRMIz/eR5aWlqo1DH0dIAUoXOPX1gEKAXH1fEYbykG8tGJqaipt375dQRozYq4RmgoDc/XOHmFwOQ1iVaymnOzBptYoOPlOC1ujrryysrIoIiJCfUEAEJBCRAcq8ZJGwpJGd3U/0oEgNgCyzRoQ8A7vTQcZoamwATMIVIEY5K8mx0QMm1+jOLdqR7PCN1CjRvYUHx9Ps2bNMnc/ASwuvrYRKOLEJukQ1m3ih4uNwfTp09WOBstOxDjrl7bAaiCmuJh2sES5TGQMq0sFd0dbGzvy6xJo5MYrvju5telE3x6Po1OnTlFBQQH17dtXdRuQEUK6K3bdBuAS1v3o6snJyRQTE0Pr16+nsrIyfhX1oagPttbYzQu4jf9cyCdv8/DJZPtvEIdrAZFHvn7bdeBzvrT5UOXDRc2cOfxOxlcBAKnvAQFetk9CUA9j74f1MS0tTX0ofCx0QQhODUMGhNPYkfP5YqmFshl/6rp+04nBf5hVTTsh/d7j5v/MWJY5jBupmHXvM5n76lQbHh5Ow4YNU34hKGRKSkrUeMnOziZoTk4OYazm5eGxxFLauHhR/4BQdWMllzWWKb4Pxa6bTPHJuIdScpR/8QKDOcOixRAOYlULBq6PF0Um1fnAl5l9hFtuCl249B3yqsMijjnOzqbjD1oEM+idO3dUvLUfFyd38vHuQ128f6YOrh3culpLVsOGB8HIRf31185BnChBEuotJrYd7MFduJoFF/82pc4bYbTK7qRVtCMxli5fPStl1HAd+LYXd4I/bP8SebB6efjxXtSfWrb4QY20DzOgC360sK/+ELiT8wzV81kj1pET4KzigoR4slkwM/6RXlzwnHo5L4MHfbH6kg7NWirgri4dGnyNDQy6YL2KWhpCmTmAqOQW//ZmzTYFTb/WiCEmkHU3a2NWkoc/+J+3LPviXTpweL3AwEzzGmuiGMSV6V7C4uaw5zrrGzDgeRQviT19hzy3V020FG58NVKANpn1H/AYpTZiSHeM1ZUVM40ih/3YK36vN+heH2U0VDCmFqx4k46n7dKLwJS9QDfo/rqIIR26I8aaIocxlMxXyV079dNfFJHuqQlmv9//cQgfqcynK9QFUlNZ1dQOg1EeRgz/HMEsiQVnMKsdtjB7U9aoRzecsp/UP3K4bAtBK63ZFEmr1n9Id/n+vlowptD90FK1kkLa2iYPxBklkA2bWNVsicj/h78cgQcESwG6gVrnYID8r/9JzMTC9BvEzmLWGqc+vHq8CH/r08HW149ujI0zLkrQ35+kokyUXZ+hwsmfrKDygazYjWLtayhB5EUZKOuxCT12AQxCF5TnyxrI2o3Vh9WL1bFa2Xk2f3b+L7RqKkSogSQ7AAAAAElFTkSuQmCC"
                                                alt=""
                                                data-v-56721eda=""
                                            />
                                        </div>

                                        <div class="nn" data-v-56721eda="">20</div>
                                    </div>
                                    <div class="progress" data-v-56721eda="">
                                        <div class="jd" data-v-56721eda="">
                                            <div
                                                class="pre"
                                                data-v-56721eda=""
                                                :style="{ width: 50 + '%', height: 100 + '%' }"
                                            ></div>
                                        </div>

                                        <div class="bi" data-v-56721eda="">0/1</div>
                                    </div>
                                </div>

                                <div class="btn" @click="Quit">去兑换</div>
                            </div>
                        </div>
                    </div>
                </van-tab>
            </van-tabs>
        </div>
    </div>
</template>

<script>
import { Tab, Tabs, NavBar, Empty, Grid, GridItem, Image, Calendar, Progress } from 'vant'
export default {
    name: 'signInPage',
    components: {
        [Tab.name]: Tab,
        [Tabs.name]: Tabs,
        [NavBar.name]: NavBar,
        [Empty.name]: Empty,
        [Grid.name]: Grid,
        [GridItem.name]: GridItem,
        [Image.name]: Image,
        [Calendar.name]: Calendar,
        [Progress.name]: Progress,
    },
    data() {
        return {
            activeTab: 0,
            currentMonth: new Date(),
            dynamicList: [
                {
                    id: '123123',
                    title: '小狗',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
            ],
            myCircle: [
                {
                    id: '123123',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '12312',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '12313',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '1233',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '123',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
            ],
        }
    },
    methods: {
        onClickLeft() {
            console.log('123123')
        },
        Quit() {
            console.log(12312312)
        },
        renderTabTitle(tabIndex) {
            return 'aaa'
            return tabIndex
            // if (tabIndex === 0) {
            //     return (
            //         <div>
            //             <img
            //                 width="117px"
            //                 height="29px"
            //                 src="https://mhsign.7qbq7qw50.xyz/assets/rw_y.f4725014.png"
            //                 alt="Tab Image"
            //             />
            //         </div>
            //     )
            // } else {
            //     return (
            //         <div>
            //             <img
            //                 width="66px"
            //                 height="17px"
            //                 src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAL0AAAAwCAYAAABE+Xs2AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAvaADAAQAAAABAAAAMAAAAABzBQT2AAAK90lEQVR4Ae2ceewdVRXHa0GRpUhbRIQWi0JdqAGVVVwqGiuSqmBFBcVUY+I/ErRKxBj/MBpjRAWKgoJRSgS1i1JMbMRYrNDESAHXUtJIsWWRtoJtkaIU/H5e3vv1Ot5z7mxvm/dOcjozZ7/3nTlz7p35ddKkMYxnYMRm4Fk5xnuYZM5z5H4g3laH30/WbDk/1wlguXjrHf6wsU5XwC83gn5c9BsN3iCSP62gZhmB3S76DQYvSc6T9BfLylcMS4+IfqTwTOFrDZlukXfI8JcTxleJP8+Q4UY9RfiEwa+D/LSMbBNy7AVcJScfMxw9KDq/1bDAagU61wiWQvsBg1cL+Y+y8oyBl7U9LDb4ll4d9Afavq0DyV6Hn6o2/qU4lgqPtQKtkU7SW/Gm5qvGMGoxdbMzlpuqeJicUD5e/DmOzPUOr5+sfeT80n4GEPjeX+cLhGuERwX08ak/Azsd9kEOL8lKJf0HHQvrxVvn8PvJ+rCcezdrP2I7XE67+kjux6AK+lwo+Ucd3C+wtys4z55OyRKKXO/rCFMtvQXsEke3nyyqwBf6GYDj21pkOiqNYpHUhzgjCteYXav0XtK/WcG90AiQvpHFxCACC2+q6hh6OwMUmrcYLu8Q/UKDZ5G9Sh9rb06QoW9ZxkR/r3AzfC/pvUfxrR0DGBGwUNvQOkv/Q8t0siG2RXRrpyirwhZcFmaIsChLDK4f0nlMLxCpfHqELBxQ2crwGThFIZ9mhF1mEe0lfay92eP4JywKuJv0B0rgHCQNuD5DX6NrMA+cJCEr6dlGvDKPEUPmi6JbCbdNPNqLfxq6dZF/JkNnlTA2Uzr0vFSsQ0voo3KMo4fNvL+RY6bFYtduRUZoeuY6vGTui0LR9uYfCQfTOnyr0p8tARI/Bk+IuCzG6DPtVfJ/gRMDj196xpXCnwp5MVXXDcA8skXKU4y2sCigc5PQmvOi9mLyzxHx9TFGCdqPIzpe0m+PyKdIuxwB5pv1wZOBTCrpJ+KbHCiFp/x4FpAw3l1o6XWb/jU5CBdCob+NurhaeIlwvvC7wr8LuXm5wUmIMsAT6wohL36o8PSNzxUWhcul0M2ELxpPGXnv6VR30hPflEyQFGPQArfS0/t41Srb2lhOekknkd/kOPyMeIwrXExRKd7dxsd0XCpkcU4LwELdgqPFYL0DzraEDPrvI/SDRTsuQh8mEnN5kBNw3e0NrvCXtUu1t946T1T6WHvzfinuI4wB1fEXMUafaT+X//2dGHaLt0RoVeFDxPtoGzfreKOQG+APQoAqca6QROf7ljLwbyn9MKIY+w0iYgNNmkgoI8peVHpc48dKerfSe63NDTK6B+sDBk8pHtCCE8QgYfPATAld3MY/6XifcJ6wbAsk1dZLvIU6buGigZBK+mxFzjMFOxNCVPoseH39RIzZKjNHVkgQCz4hBniL8K2W0ADSuZGtft8Ll/kAywAt04+EPGHWljHQ1vm8jqwX8sBnJbTAENwqOjdvHqBf/nUewbaM188j0o1KH0t6z49Z6fNWwwLzMRCiixTFd4QkP2N8kbAbwNNmlZBEXyl8UlgV7peBu3Ia2ebI/aeAHdq9IjBRRQ0lLy5DZdIui9Gmc2NmIVelnxxocX5+cN200w0a0OeERwvfKFwurAv4nuSTQvrJ+UIWxXUkvMwMBXhJTyHYUWIUOxM6tVT6uXIyI+Fo2Nn05W8XUvHPqnEwU2XrIuHhQhbBdwtHCbz2hpbD2w2z5oknE4t/ay0VS3qv0kfbGxJhWGGWAn9XIviXis8OzMTgE/JF2Xw23FkA36PzZUJ+cAueFuMKizlkdK/Se3OQGiYtjvV7TYkoe0lPy8au5J5wIbtYhGsDQ5fq/NTgepBPqbDfGKAAX6ZYaKU8YGHZlKRPVXpvHjweLY6V9LFK791gbGSQ+NvDpL8z450+NQ+cJqFwbZDSOcwRYCCnO/wY6y8iPhxjVKStkz4v4nihtED4PqFX0cQuBI8Ukh5sYW9etlUInUpvQdFKjx3i/J+kt4yn6L+SgPXSJ6Wb5R8rwm1ZYuKaHn11QiYvmxdTvJQi2bmZOnCrTtiqPVNIGzhfuJ+wCvCirynQzUpvzVHRSo+d1lMjrPSW8WGg71aQjwl5fBUFHqHLhSQ7NzC9dgxYWK1sI37eI+QGeJ2QR2dRGFf69Ix5lT6W9F5Pj7fWE6lIW5IOsb8SDxVwv0eyq4TnC1kPfER4uXCFkDbmQKEH3GDXCN8gfLGQ/p0t0SIwrvTp2fKSvkx706hKz/RdJSQBPeArvHuFJHy4DqBqv6KN79SRPzS5Wcj2I7JsnVmwSYwvtfHVOp4ofInQ2moTqwXYbQLQLTzPGUiVnp6nsAWxSs+7EX47q2g1LukXW7OTg85WYwhMGhUf5CZhNybPXjObAdkNAZEaDa1Ecka43eGlWF6ljyU99mhxrKRvtTd19PS3yEmqqhFMB16pkyM6F5kjd/baDC11WaWSYPsMIdXZAnr9PAlv6TedfmhigN1K+lh7Qyj4m2nEVFulf4fhwCJfJ8YFBnOj6G8zeN0iZ6t86Ge3Lmib+gmvkXOKQR7gEwsL2GE722Jm6FYVzYi1LlvVM8Zo06oUJW/cVoxUegtasdZR6S0HvaSfLGe3l3TozQGJ8mBJu57ax8W82hMIeBfqHKwKVLkVVY1E9Aex0kfCbJFqq/SWg17S2TL0krdKLN2w26RdM6/Ss/2b9yVn7DfyKj19O797tvVMVvomTX5s0sa07swAOyQd8Co9CW+99+joe8ddDpOEPyDC99YQrUo/TvrIrI1J7gxQWVcHEl6lr9LP48JLevixxey40jMzY6htBtgH/5BwU2DRS3qv6gYmzFOvvUEptpj1fB4snX270a+aI+gig08EilQVBu9ts/JY5q1tFfAe+6FdEmlJSKhwfqp0Zxv6vJhbavBSZJLvHiF//rg1I+yNs8hvkjHbukxV+ljSe5Ueo1ObkvR3ajDPb01T+p9nS+Q+4ZGG6AOis/XHjVQWuKFI5jxAf0z1rAPYXrWSnhu5Lj9hrN2s9KmkL9reEPf0piR9+COkzs+TgJXw6F4prJLw2Bgl8Cq912rkmaO/SmiOI7gpwkv5nDZqSc+K/1ORieqQqLrf7lyMj7lmwKv0Vdsbis+fc0WxVyjV3kwftd0b3vZ6leN74lfZV9479aNxRv5MdYaaqrqOamlWKumnjVrSe58csJ/M58VjyD8DJLyXQ1Urff5I9krydPB2fUaq0p+oyZi7d27+72ylKHz7M4b8M+D181jpR6VP+a2lp3+BvPAXRHnhOEcQW17PnVX9jQi/bRPZcYm9oevo8IceHnzdY2Z4x+ua73IsYIdoFMDr5xl/0Up/knS8v11Izel6CewQ0uLMEsaglqSfIctfjVkvQeOT4yK2LpF8J+nZrptXwicqvxNyA+WFZRI8Jq9wg+VSSV+00q+pOFdnSH+10OvrG7VlWeTPBbNzW6TKZ3VH+Zrdv3uNCXhGdC/5DLVayOz4HGVYerxJW5Zlk/5vmhwqdy+B7/SbAD/RIMC8UOXjs7w+kLuojVGdyVHqcBLLJv1iDfepHg+57Lf/PQ6zdnd3126xhMEmJf3DJcb/S+l8s4ReFRUW1BuqGBhiXdZO3+93/F57w11pfZR1VxD4Zp0vCq57eXpb4GyjzjuL2oAcPd0i6h3Cy4RlWo210rtfmBfYkSC+64Tr8iqVkONpZ73BHIT/Z4c+f6GQdvIcIX/LWmfhfVT2kvBfBHULfUFL0CoAAAAASUVORK5CYII="
            //                 alt=""
            //                 data-v-150bd379=""
            //             />
            //         </div>
            //     )
            // }
        },
        renderTabTitle1(tabIndex) {
            return 'ttt'
            return tabIndex
            // if (tabIndex === 0) {
            //     return (
            //         <div>
            //             <img
            //                 width="66px"
            //                 height="17px"
            //                 src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALoAAAAwCAYAAACmJWBPAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAuqADAAQAAAABAAAAMAAAAABTl3i9AAAM3klEQVR4Ae1bD7BWRRWXf2IqIipgpgIWkgqCAhEjxgtQEyREC5wsG56lheFYTI2WZCiOThNqzojF1DhMqRWhZahDpTACkpoik4oUwlNEkkTAP0EK2O8Hd51lOefcu/e7l/d9731n5ry7+ztnz/65Z3fP7v3eAQfUqT4CrWAE2hh9PB6yfor8A+APKbIs8EgoHaQorgG+UpFZ8AgIuykK64AvVWSEh4HHKvIdwKeBdynyPPAYFOqtFJwLfL0n64/0ZV4+TF4LYHMCHoPnD0KFJL8BzxmKrGi4HQx+DKy946Lr8+3xXW/zgbR0XyjQoTUekmZAkXMC0Wk0uxcq5dLgxwyb96UUnm+UrWRCa9VOMeqj4/o0HhltrIhzPB1NRkLTneWUSnwOgO154PfAWjvKxs+U+tdeAhPsOTxfAJ+s6EwE/oQis+AJEGo7yTuQleFYVnu6QHi2oTAKsrcNuSZaDcFt4DmCAp2BsraC7CJgeVfe8wR7DhqGROzYbkWZFeDZ4DfBFg2F8M/gQy2lapVxy9Zm4KuQaQ5r9ecpw+avrYIpsrwreqPRHq3vMbgWdljtPcXra9YV/RCU2V5SX7bA7kCvTVLy9yXVHTPW1BVXdGlF8TvxWz8TpBmDiUYDPT/7cWQG+UCQtuoLVAvLcmcqk76hGP+dghPO06azUK6jYbMSUWcUvjvFgPVeU4qWL05z9H+iCcuNZsS+EG7LGnHVWKAJS8K7wu7Ikmw7s++6RPBk+KIdcGPHlabHBvaLzvaBwaMNozyAVi21D1rWHfkrwUPA3RLZsclTekwCGLOq95CMJNiBeP5dkC8DdrmAFwHx4Fv2C5qvNHQD8MXg4YL8RGADwM8KMgliCDlGEhSM5Y2/Gea+VFBbDoadwbG2fEdn4UfAnSKMfAS6/SL0LVV2QLL1b6XQ/cB7ebJPeOkwOQKAcxqusGckCnlWztB2Wt668ZmLwpKj0ybb5trMvEV8d1ykJNoGkIfKLNQBSkdmUYzUYZg2NbKMps5FYJUmzIK/CCUG89XGPMlLtBJgnra6l/5RlN9p2LhAqlTAuONo7fiHoO9DDAW0NqxJFLMcRm+ArtaGq/wKU9IDDTu0by0m64yyM1PqjRHT0bW+Ej9TMuZWdL70PpJCC8a+gL5pZ5S3IMtyFcewbogxRtZqzmLcraaBebCX6CgJFLCxAuYgLXRy8lbxdI7eqVX0du9OTtw7u1fuD8ht3wuRM1z1rSvWNEenVd5maLEvw6wsxJXYteMYpN17ZdkdYPdRiRN4C0GFDlPwmof9Aan5zkR0gBP7f+CFSplfKngIc1fQiKHHCk3o4UuQlg783Ia7enpWkuGPI4Yq33aZ4MlQagBYuu3pDjxrvwOz1Z/N6uiN6IrmFEX08i4YaSjCUEYbb0NvpKfbDumTwFz5uDJyIqTdYvAg7g61SO5DPDD5Nng2oFP7dAIykpNTh065iYlImgH9SeDDhXL9gH0FPCeQcUdhqNYrwP3se8i86gO1mE4L8M8tuVMcZK5gEmuH0eOgT0dx/KRSnjYXeHo9kfbpfGS4+kp1F4lJV6eNRr23JY3MchhNVD98fNew+wpk/o+tuNg9bOi7MeAEsqiqD6NtrZZXuYwDSwd1bMXUjHWdXhPSjoYiwSs+ayVzumU8GwyjCw1Zmuh2KLysKHGBmOLJZiP9OS8vJecB/KEkqBWslh29iDHmgZQrWnNRg1LxLuCPKbIsMM8f1xqK10DWBTwdPMnQo2gx+MtgtqlmqTlfcjUMGg9gzUXcRbi6SrQCoPuNuSTPgvE25zvg0wRlOjnDucGCzIeeR2Yc2NotfX0tfQUEjZowEud5Kppau6NHD1iBBRoMW7FhC89QUwV7nQTMQWlOvh6KtFvphGN9HRNmulmo7uj6sH8PoiWJmGHAaEV1NfBLEllPPO9J0mmPBkMh1tF5YBxp2IsVbUUBOjnPQbVGDNv2obqj7zMkHwIvIsXP+6SNex7iXx50nV7M6jdctLbnJwGMi2NobYxyii4dhTdRvN6sNeK18XKp0a39MCqNyf7AeqKSHkpFfFFcUWOoCcpc1Ssl2uDutKhSQ81QnoflK8HvS3XXV3RpVMrHGowqFhoyTcRVeAOYn//z0k4UpKPwl4Z5iAfWSg+tsfVyod4EXgq+Ffw4WKS6o4vDUjrIL6r80ijRowHIlUrT9VWfQGagD2RMvwM93q7cAv5bxjKSWm8JrBYsq6NztlxXYqM/WaLtajT9dTSKnIX+CCXeWqQRf2BWJ2UEsjp6H6V8rcAnoaE/BXNr5/bGidtS6FvoCD/6cAt/02Pm14PzhiIoahKvJ78E5kp+oKmZTfh5qPmhz1DkJ4ALsZ/V0bM1tRwtbt0STQZIxz0azA8/p4I14o7hdg0euFqSox+B/pyudPw14GU4+kzY5ceoIsn5YhsY/Rn4sjKMF2mzaFvLFYMMpbopMgvuagnrstQR4MpbtJP7lV6MTKFOTuNuFvkVVVN6IxrzC6VB/wGe19E7o+wIsPYJnlVy63Tj04OAQrQ1PpEdq+gQ7gKm3pPgTmC+0CLoM4YR1nODIY8VTUOBc2ILReqfHakfpX4itLmlVwvvQFvuB1tng4U52/s6yp2Ws2wR4/NF1D2uGeuvpA9o9u7/iKrEhlbW/ZfVA2WMjVuxmmD8FLBE1OFvqTtIQmDTwWlx4HDozFLKEx4NfjmR08mbwGlXalzR89CRKMQ4sE6taASco9OpXlD63Q+45uQs8iBYK0s5qdeeh/r3X5CsVqWyIMbRl8PETeDXwBvADDfqVPwIrITJSxWzo4Bfr8iyws9AkbdMEvHscLUkIOYcXZMT5zWSRvwit0ITlozfC/vcaRiKkHlSHwSWqAngXE/A0KW5qCXvJvz4tEwZ2B4KHgNvNexrEclu+5U6Op08LcSI6UiM7hIokx1tc4kqfzJGrdN+HoFKHf2p/dzeoqrbAkM87FrUDsKxYGsF5kRfYxkRZOuBvQHmDUYeYnsmg/n9IJZmo8C62EItQT/N0Tuik9aHGF6V1SKtRaMvSGn4FZAz7tOI2yivwjZqCin4jBS5Jp4JQR4np73PgnkxwHNKq6I0R++P0bAOomU5Ou+YJylvYjrwxYqsKJgfldIckX3n77YlehRg7OFashNiNwGo5GNNb5R/BNwAzjtBUbT2KM3RrYMoV7RVJXW5F+yOVGzfqeBFwjfD2OGGQf5TwjDwWYoOD8mfBu9U5HngH6HQ1SkFN0O+HMyPYRrxdz90dq7uDKFaBbVN6aXl6E+jbEs8WNFBtd2Ew0Xn/Sr4OmYU4u3PVYosD/x9FLLqo823wOeAR4MXgC3qC+FfwF0spZYkS3N07bqOY1BW2NKc48vxuAPcxmgE5Vw1bwFzsmt0PQQnaMIIfCp0b0zR57XeuWBeDvDKdzx4IdiiARByQnS2lFqKzHL0Q9FJbnMatURHvxydPV3rMHAe4qYlcq7sl4L5JVeigwH+XBJEYFOg+5MUfV6rjgU/7uk5bKmHSUnu2A+D+a5bNDFG54vtIPSyHzBrIhR5tdgbdXX02pD1x1r8QZNruxVTe6Z3Jw/C3zMCkHZuDLAwy9WVIYKjFUj8GMzQQqJRABkG3SUIOfbW+DZCfrtQzoe4ep8PXuSDSfpdPEeDGaJ8KsGkx1CAD4J5w8QJotH7EHygCROcodA4RceKDpQi+8BHGfa5Q5n0LKTsQAzzU3oMjYFyjH1L90Kv4k0Z7d7nlWGSk4orsVVPKPsrCwpEWyvBob7Ls43dhXIPGWVcWevJD3XnCXZDiM73DNiylUV2XGL47gJsSfW5XeWBMuxzReFLiqVaD1u4Er4U0Wk6Fe/VJaKtr4H58iQ6AqC0MsfUH9rlJL0IPD8UCPnNwHjf/5wgywpxNV+fVbka9fI6emzYojlBnjHJY4vxdEjPh4CRZ5y8ypAvhWyWIZ8AGUMDn/I6+i4YuQQc7lK+7TD9BgCGUVYfwjJ+/hVkWG9ZtBWG/1uWcdh9Pa+jL4tsFO+di6I8tp4WKs+6wjWh7AyhfAhdA4AOodEdEBzmCfM4Oic5D8D3enayJvnDN36byFPv2qyV5NT7E8qVOZF273x9UQkHMCszbOEEiaVbUSBrHZrenUGlWWJ0OrnvYM7ExAztoXMMdAUyPHnFp7WduL/qn5yiG9rhikcnr5SOhwFO8tC+lZ/tVVp0jM6zj4vPWU3RMTrtH8L7Yh6mFoGtu2MOAmN5btHs6HZwHuItwMXgnuB24CzEmd4E/g2YM59tcfQrJDq5jPekDifBEvA9YMbYIfUGEE4cp7MNCU6QOeC1Dsz45FfVQYou+0JnXQfmzQ8nfxoxHm8Cz0ueeFRM7WGBE70/WBq/sALeyuxeFfFsBA8OFXLkeaGxGLwoKPtN5E8NsDzZvez/H53U90UTTHjaAAAAAElFTkSuQmCC"
            //                 alt=""
            //             />
            //         </div>
            //     )
            // } else {
            //     return (
            //         <div>
            //             <img
            //                 width="117px"
            //                 height="29px"
            //                 src="https://mhsign.7qbq7qw50.xyz/assets/dh_y.e6ba675a.png"
            //                 alt="Tab Image"
            //             />
            //         </div>
            //     )
            // }
        },
    },
    // 组件的逻辑部分
}
</script>

<style scoped>
::v-deep .van-calendar__month-title {
    display: none;
}

::v-deep .van-calendar__month:not(:nth-child(2)) {
    display: none;
}

::v-deep .van-calendar__month {
    color: white;
}

::v-deep .van-calendar__day {
    margin-bottom: 1vw;
    height: 8vw;
    font-family: PingFangSC-Medium;
    font-size: 4vw;
    color: #fff;
    letter-spacing: 0;
}

::v-deep .many .total {
    display: flex;
    align-items: center;
    text-align: left;
}

::v-deep .van-nav-bar {
    position: relative;
    z-index: 1;
    line-height: 22px;
    text-align: center;
    background-color: transparent;
    -webkit-user-select: none;
    user-select: none;
}

::v-deep .van-nav-bar__title {
    font-family: PingFangSC-Medium;
    font-size: 4.5vw;
    color: #fff;
    letter-spacing: 0;
    padding-left: 8.75vw;
}

::v-deep .van-icon-arrow-left {
    color: rgb(255, 255, 255);
    font-size: 20px;
}

::v-deep .van-nav-bar__text {
    font-family: PingFangSC-Medium;
    font-size: 3.5vw;
    color: #fff;
    letter-spacing: 0;
}

::v-deep .btnsign {
    margin-top: -46px !important;
    width: 73vw;
    height: 10.5vw;
    margin: 0 auto;
    position: relative;
}

::v-deep .btnsign img {
    width: 100%;
    height: 100%;
}

img {
    overflow-clip-margin: content-box;
    overflow: clip;
}

::v-deep .van-tabs__content {
    transition: transform 0.3s ease-in-out !important;
}

/* 在这里可以定义组件的局部样式 */

::v-deep .van-empty__image img {
    display: inline-block;
    width: 81px;
    height: auto;
}

::v-deep .van-empty__image {
    display: inline-block;
    width: 81px;
    height: auto;
}

::v-deep .cover {
    width: 70px;
    height: 70px;
    border-radius: 6px;
    overflow: hidden;
    object-fit: cover;
}

::v-deep .btn {
    width: 62px;
    height: 28px;
    line-height: 28px;
    text-align: center;
    background: #f898c6;
    box-shadow: 0 3px 5px #4545450d;
    border-radius: 16px;
    font-family: FZLTZHUNHK--GBK1-0;
    font-size: 12px;
    color: #000;
    letter-spacing: 0.38px;
}

::v-deep .info {
    flex: 1;
    text-align: left;
    padding-left: 10px;
}

::v-deep .name {
    font-family: PingFangSC-Semibold;
    font-size: 16px;
    color: #333;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
}

::v-deep .circle {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}

::v-deep .num {
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #666;
    letter-spacing: 0;
    margin-top: 13px;
}

body,
html {
    margin: 0;
    padding: 0;
}

#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
}

::v-deep .home_t .info {
    padding: 12.5vw 0 0 2.5vw;
    display: flex;
    align-items: center;
    margin-top: -40px;
}

::v-deep .home_t .info .times[data-v-9de6fb96] {
    text-align: left;
    padding-left: 2.5vw;
}

::v-deep .home_t .info .times .yqd[data-v-9de6fb96] {
    font-family: PingFangSC-Medium;
    font-size: 4vw;
    color: #fff;
    letter-spacing: 0;
}

::v-deep .home_t .info .times .yqd span[data-v-9de6fb96] {
    font-family: PingFangSC-Medium;
    font-size: 4vw;
    color: #fbde0b;
    letter-spacing: 0;
}

::v-deep .home_t .info .times .tomm[data-v-9de6fb96] {
    font-family: PingFangSC-Regular;
    font-size: 3.25vw;
    color: #fff;
    letter-spacing: 0;
    margin-top: 1.25vw;
}

::v-deep .van-calendar__selected-day {
    width: 27px;
    height: 27px;
    border-radius: 13.5px !important;
    color: black;
    background-color: yellow;
    border-radius: 4px;
}

::v-deep .many {
    flex: 1;
    padding-left: 2.5vw;
}

::v-deep.many {
    flex: 1;
    padding-left: 2.5vw;
}

::v-deep .many .progress {
    display: flex;
    align-items: center;
    margin-top: 1.25vw;
}

::v-deep.many .progress .jd {
    width: 35vw;
    height: 3vw;
    background: #eeeeee;
    border-radius: 1.5vw;
}

::v-deep .many .progress .bi {
    font-family: PingFangSC-Semibold;
    font-size: 3vw;
    color: #666;
    letter-spacing: 0;
    margin-left: 1.25vw;
}

::v-deep.many .progress .pre {
    background: #fbde0b;
    border-radius: 1.5vw;
}

::v-deep.many .total {
    display: flex;
    align-items: center;
    text-align: left;
}

::v-deep.many .total .tt {
    font-family: PingFangSC-Semibold;
    font-size: 3.75vw;
    color: #333;
    letter-spacing: 0;
}

::v-deep .many .total .ii {
    width: 3.75vw;
    height: 3.75vw;
    margin: -0.5vw 0 0 2.5vw;
}

::v-deep.many .total .ii img {
    width: 100%;
    height: 100%;
}

::v-deep.many .total .nn {
    font-family: PingFangSC-Semibold;
    font-size: 3vw;
    color: #333;
    letter-spacing: 0;
    margin-left: 0.5vw;
    margin-top: 1px;
}

::v-deep .many .progress {
    display: flex;
    align-items: center;
    margin-top: 1.25vw;
}

::v-deep .home_t .info .avater[data-v-9de6fb96] {
    width: 15vw;
    height: 15vw;
    border-radius: 7.5vw;
    border: 0.5vw solid #fff;
    background: #fff;
    overflow: hidden;
}

::v-deep .home_t .info .avater img[data-v-9de6fb96] {
    width: 100%;
    height: 100%;
}

.rl[data-v-19ecb41f] {
    height: 61.25vw;
    width: 90vw;
    margin: 21.25vw 0 0 5vw;
}

.rl {
    --van-calendar-background-color: none;
    --van-calendar-weekdays-height: 5vw;
    --van-calendar-weekdays-font-size: 3.75vw;
    --van-calendar-header-box-shadow: none;
    --van-calendar-selected-day-background-color: none;
}

::v-deep .van-calendar__header {
    box-shadow: initial;
}

.rl .van-calendar .van-calendar__header .van-calendar__weekdays .van-calendar__weekday {
    font-family: PingFangSC-Medium;
    font-size: 3.75vw;
    color: #333;
    letter-spacing: 0;
}

.rl .van-calendar .van-calendar__body .van-calendar__month {
    height: 100%;
}

.rl .van-calendar .van-calendar__body .van-calendar__month .van-calendar__month-title {
    display: none;
}

.rl .van-calendar .van-calendar__body .van-calendar__month .van-calendar__days {
    height: 100%;
}

.rl .van-calendar .van-calendar__body .van-calendar__month .van-calendar__days .van-calendar__day {
    margin-bottom: 1vw;
    height: 8vw;
    font-family: PingFangSC-Medium;
    font-size: 4vw;
    color: #fff;
    letter-spacing: 0;
}

.rl .van-calendar .van-calendar__body .van-calendar__month .van-calendar__days .select_day_list {
    font-family: PingFangSC-Medium;
    font-size: 4vw;
    position: relative;
    color: #000;
    letter-spacing: 0;
    transform-style: preserve-3d;
}

.rl .van-calendar .van-calendar__body .van-calendar__month .van-calendar__days .select_day_list:after {
    width: 8vw;
    height: 8vw;
    border-radius: 4vw;
    background: #fbde0b;
    content: '';
    position: absolute;
    top: 0;
    left: 2.5vw;
    transform: translateZ(-1px);
}

.rl
    .van-calendar
    .van-calendar__body
    .van-calendar__month
    .van-calendar__days
    .select_day_list
    .van-calendar__selected-day {
    color: #000;
    z-index: 2;
}

.btnsign .text {
    width: 73vw;
    height: 10.5vw;
    left: 0;
    top: 0;
    margin-top: -43px;
    text-align: center;
}

.btnsign .text span {
    font-family: PingFangSC-Medium;
    font-size: 4vw;
    color: #000;
    letter-spacing: 0;
    line-height: 10.5vw;
}

.btnsign .text .n_s {
    display: flex;
    align-items: center;
    height: 100%;
    justify-content: center;
}

.btnsign .text .n_s .tt {
    font-family: PingFangSC-Medium;
    font-size: 4vw;
    color: #000;
    letter-spacing: 0;
}

.btnsign .text .n_s .ii {
    width: 4.5vw;
    height: 4.5vw;
    margin: 0 1vw;
}

.btnsign .text .n_s .ii img {
    width: 100%;
    height: 100%;
}

.btnsign .text .n_s .nn {
    font-family: PingFangSC-Medium;
    font-size: 4.5vw;
    color: #000;
    letter-spacing: 0;
}

.tasklist {
    margin-top: 7.5vw;
    padding-bottom: 7.5vw;
}

.tasklist .item {
    height: 13vw;
    margin-bottom: 3vw;
    display: flex;
    align-items: center;
}

.tasklist .item .many {
    flex: 1;
    padding-left: 2.5vw;
}

.tasklist .item .many .progress {
    display: flex;
    align-items: center;
    margin-top: 1.25vw;
}

.tasklist .item .many .progress .jd {
    width: 35vw;
    height: 3vw;
    background: #eeeeee;
    border-radius: 1.5vw;
}

.tasklist .item .many .progress .bi {
    font-family: PingFangSC-Semibold;
    font-size: 3vw;
    color: #666;
    letter-spacing: 0;
    margin-left: 1.25vw;
}

.tasklist .item .many .progress .pre {
    background: #fbde0b;
    border-radius: 1.5vw;
}

.tasklist .item .many .total {
    display: flex;
    align-items: center;
    text-align: left;
}

.tasklist .item .many .total .tt {
    font-family: PingFangSC-Semibold;
    font-size: 3.75vw;
    color: #333;
    letter-spacing: 0;
}

.tasklist .item .many .total .ii {
    width: 3.75vw;
    height: 3.75vw;
    margin: -0.5vw 0 0 2.5vw;
}

.tasklist .item .many .total .ii img {
    width: 100%;
    height: 100%;
}

.tasklist .item .many .total .nn {
    font-family: PingFangSC-Semibold;
    font-size: 3vw;
    color: #333;
    letter-spacing: 0;
    margin-left: 0.5vw;
    margin-top: 1px;
}

.tasklist .item .icon {
    width: 13vw;
    height: 13vw;
    border-radius: 6.5vw;
    overflow: hidden;
}

.tasklist .item .icon img {
    width: 100%;
    height: 100%;
}

.tasklist .item .name {
    flex: 1;
    text-align: left;
    padding-left: 2.5vw;
}

.tasklist .item .name .miss_n {
    font-family: PingFangSC-Semibold;
    font-size: 3.75vw;
    color: #333;
    letter-spacing: 0;
}

.tasklist .item .name .integral {
    display: flex;
    align-items: center;
}

.tasklist .item .name .integral .ii {
    width: 3.75vw;
    height: 3.75vw;
}

.tasklist .item .name .integral .ii img {
    width: 100%;
    height: 100%;
}

.tasklist .item .name .integral .nn {
    font-family: PingFangSC-Semibold;
    font-size: 3vw;
    color: #333;
    letter-spacing: 0;
    margin: 0.75vw 0 0 0.5vw;
}

.tasklist .item .btn {
    width: 16.5vw;
    height: 7.5vw;
    background: #f898c6;
    box-shadow: 0 0.75vw 1.25vw #4545450d;
    border-radius: 4vw;
    font-size: 3.25vw;
    font-weight: 500;
    color: #000;
    letter-spacing: 0.38px;
    line-height: 7.5vw;
}

.tasklist .item .finished {
    background: #eeeeee;
}

.prize_box {
    width: 72.5vw;
    height: 56.5vw;
    background: #ffffff;
    border-radius: 2.5vw;
    margin: 70vw 0 0 13.75vw;
}

.prize_box .title {
    font-family: PingFangSC-Semibold;
    font-size: 4.5vw;
    color: #333;
    letter-spacing: 0;
    text-align: center;
    padding-top: 4.25vw;
}

.prize_box .p_img {
    width: 13.5vw;
    height: 13.5vw;
    margin: 4.25vw 29.5vw;
}

.prize_box .p_img img {
    width: 100%;
    height: 100%;
}

.prize_box .name {
    font-family: PingFangSC-Medium;
    font-size: 4vw;
    color: #666;
    letter-spacing: 0;
}

.prize_box .sure {
    width: 52vw;
    height: 10vw;
    background: #f898c6;
    box-shadow: 0 0.75vw 1.25vw #4545450d;
    border-radius: 5vw;
    line-height: 10vw;
    margin: 5vw 0 0 10vw;
    font-family: PingFangSC-Regular;
    font-size: 3.75vw;
    color: #000;
    letter-spacing: 0.83px;
}

.prizelist {
    margin-top: 7.5vw;
    padding-bottom: 7.5vw;
}

.prizelist .item {
    height: 13vw;
    margin-bottom: 3vw;
    display: flex;
    align-items: center;
}

.prizelist .item .many {
    flex: 1;
    padding-left: 2.5vw;
}

.prizelist .item .many .progress {
    display: flex;
    align-items: center;
    margin-top: 1.25vw;
}

.prizelist .item .many .progress .jd {
    width: 35vw;
    height: 3vw;
    background: #eeeeee;
    border-radius: 1.5vw;
    overflow: hidden;
}

.prizelist .item .many .progress .icon {
    width: 4vw;
    height: 4vw;
    margin-left: 0.5vw;
}

.prizelist .item .many .progress .icon img {
    width: 100%;
    height: 100%;
}

.prizelist .item .many .progress .bi {
    font-family: PingFangSC-Semibold;
    font-size: 3vw;
    color: #666;
    letter-spacing: 0;
    margin-left: 1.25vw;
}

.prizelist .item .many .progress .pre {
    background: #fbde0b;
    border-radius: 1.5vw;
}

.prizelist .item .many .total {
    text-align: left;
    font-family: PingFangSC-Semibold;
    font-size: 3.75vw;
    color: #333;
    letter-spacing: 0;
}

.prizelist .item .icon {
    width: 13vw;
    height: 13vw;
    border-radius: 6.5vw;
    overflow: hidden;
}

.prizelist .item .icon img {
    width: 100%;
    height: 100%;
}

.prizelist .item .name {
    flex: 1;
    text-align: left;
    padding-left: 2.5vw;
}

.prizelist .item .name .miss_n {
    font-family: PingFangSC-Semibold;
    font-size: 3.75vw;
    color: #333;
    letter-spacing: 0;
}

.prizelist .item .name .integral {
    display: flex;
    align-items: center;
}

.prizelist .item .name .integral .ii {
    width: 3.75vw;
    height: 3.75vw;
}

.prizelist .item .name .integral .ii img {
    width: 100%;
    height: 100%;
}

.prizelist .item .name .integral .nn {
    font-family: PingFangSC-Semibold;
    font-size: 3vw;
    color: #333;
    letter-spacing: 0;
    margin: 0.75vw 0 0 0.5vw;
}

.prizelist .item .btn {
    width: 16.5vw;
    height: 7.5vw;
    background: #f898c6;
    box-shadow: 0 0.75vw 1.25vw #4545450d;
    border-radius: 4vw;
    font-size: 3.25vw;
    font-weight: 500;
    color: #000;
    letter-spacing: 0.38px;
    line-height: 7.5vw;
}

.task {
    width: 95vw;
    margin: 0 auto;
    margin-top: 5vw;
}

.task .header {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 7.5vw;
}

.task .header .tab {
    width: 15.75vw;
    height: 4vw;
    margin-bottom: -1.25vw;
}

.task .header .tab img {
    width: 100%;
    height: 100%;
}

.task .header .tab2 {
    margin-left: 5vw;
}

.task .header .active {
    width: 28.25vw;
    height: 7vw;
    margin-bottom: 0;
}

.task .header .active img {
    width: 100%;
    height: 100%;
}

.home {
    width: 100%;
}

.home .stick {
    width: 95vw;
    position: fixed;
    top: 0;
    left: 2.5vw;
    display: flex;
    height: 12.5vw;
    align-items: center;
    justify-content: space-between;
    z-index: 999;
}

.home .stick .record {
    font-family: PingFangSC-Medium;
    font-size: 3.5vw;
    color: #fff;
    letter-spacing: 0;
}

.home .stick .title {
    font-family: PingFangSC-Medium;
    font-size: 4.5vw;
    color: #fff;
    letter-spacing: 0;
    padding-left: 8.75vw;
}

::v-deep .home_t {
    height: 122.5vw;
    background: #ccc;
    background-image: url(https://mhsign.7qbq7qw50.xyz/assets/h_bg.f104dc84.jpg);
    background-size: 100% 100%;
    background-repeat: no-repeat;
    position: relative;
}

::v-deep .home_t .total {
    position: absolute;
    right: 3.25vw;
    top: 42.5vw;
    display: flex;
    align-items: center;
}

::v-deep .home_t .total .tt {
    font-family: PingFangSC-Medium;
    font-size: 3.5vw;
    color: #333;
    letter-spacing: 0;
    text-align: right;
}

::v-deep .home_t .total .ii {
    width: 4.5vw;
    height: 4.5vw;
    margin: 0 1vw;
}

::v-deep .home_t .total .ii img {
    width: 100%;
    height: 100%;
}

::v-deep .home_t .total .nn {
    font-family: PingFangSC-Medium;
    font-size: 4.5vw;
    color: #000;
    letter-spacing: 0;
}

::v-deep .home_t .day {
    width: 13.5vw;
    height: 13.5vw;
    position: absolute;
    left: 2.5vw;
    top: 33.75vw;
}

::v-deep .containers {
    display: flex;
    margin-top: 20px;
}
</style>
