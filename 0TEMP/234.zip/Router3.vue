<template>
    <div>
        <van-nav-bar title="圈子" left-arrow bind:click-left="onClickLeft"></van-nav-bar>
        <van-tabs v-model="activeTab" type="line">
            <van-tab title="动态" v-model="dynamicList">
                <van-empty
                    v-if="dynamicList.length <= 0"
                    class="custom-image"
                    image="https://mhw.p2lfie.com/assets/ic_none.3df97c45.png"
                    description="空空的什么都没有"
                    title=""
                />
                <div v-for="item in dynamicList" :key="item.id">
                    <div class="circle">
                        <div class="cover">
                            <van-image :src="item.icon" fit="cover" alt="Image Alt Text" />
                        </div>
                        <div class="info">
                            <div class="name">
                                <span>
                                    <van-image
                                        height="15"
                                        width="15"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC0AAAAtCAYAAAA6GuKaAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAALaADAAQAAAABAAAALQAAAABGqAVQAAAHNUlEQVRYCc2ZT2xVVRDGp4X+QcDStNiWFKWACRRoIq3YgCSNmLASMW4w6IZEYtQFuAGWLoysABMXRhMTIyYuNKjdSEyTJtpase2mNDShpdqW0gqNaQGhtBTnd96by3mXe19fy4P0S+ade8+dmfe9c+fMmXNejjw8ytXFKyq1Kqs8KdHrMZVhTzr0ulFlROWx42n9xiMqrSozKvfmIOhjhz1+HjkYvRMqkypzIRqnix/84Tdj5GSoWaB6h1WOqhT5Njk5OVJaWirl5eWydOlSKSwsdFJQUCCTk5Ny+/ZtJzdv3pSRkRG5du2a3LvHb0jBuN4dVzmpwg9Ji0xIE7NnVOp9TyUlJVJVVeXI5uXl+Y/SXk9NTTny/f39MjZGyKegTe9eU0kb87OR3qoOflSpVHFYvny5bNq0SSoqKqxr3u2VK1eku7tbrl+/7vsY0ptXVTr9Tv86Hek9qvityhIMCIMtW7bI2rVr3TV92QCh0tfXJ+fPn/fD5pb63qfyU9R3xJGuVeVfVRzh/Px82bZtm6xcuTLKR1b6rl69KufOnZM7d+6YP4i/qPLAiEeRJob/VHEhsWzZMtm+fbubZNr3SMFkbW1tlRs3btj3ECrPq6TE+CJ7mmzJEj+rVHPPCO/cuTNjwrzq6elplSmZmpqUmZkZ98pzc3MzCim+jyw0ODgod+/ehcKTKoz2aRXXoa2ER/qo9n3sHmgM79ixY9aQgCgTamhoSEZHRx1p7H0sXrxYysrKpLKy0k1g5kc6ECotLS1+jB9T/eNm41uT4PtUXB6uqamRdevWmV5ki/Ouri4ZHyfNZoaioiI3oWebH729vc530itfABmXI/3w+Eg7G1SEtFZbW5v2lfb09EhnZ6dbQLAxPKMz4bnNWojUiJTpvGUdGZ+wp7py6IIzMDDgfLMoxaG4uFguX75sE7NQ9VgMzqJvI00NcFEln876+vq0ebi9vd3FHbrgCc0xh94W2f+6yIZnE33+Z496Pv29yCdfiPxHTkhi9erVUldXZ7cPtIRdW1ub9ZNW8D5gI/2O3uzmKSvd5s06VDFghMmrht0NIk3fiexR61ICLAL0v6TT6cAbIt09GoN/JZQmJibSjjhvnBC8dcv9UriOqrTkJsxlb7J1S7Ndh1scXLhwIeg++KbWmV+LlD8VdKW9QA997Az4w28cKBU8OJ6QJi+/wANmNSknCmQJJp2BEf5U88wie1f2YJYWfeywN+AX/1GAj5dt4FkOaZZrF9tMjLjih/iyLEEMf3lq7oSNFMSxxw/AL/6jAB9vwsLzFUjXmnLcKPOcPGxg0mUaEmYTbrHHj8H3b33WhnjVQToo16iHo8CrY+EwkCWyAd8P/llBoxDiVQFp9nUOFPBRSCzN0+4ReTgqrUXZzdaHH/wBvoPaIwohXqtSSC9ZkgyykOXMTLDsS1WWd3W+P3Y5UQjxcqQ1iyZAwRIFn3RJcZTG/Pt8f15ZmuIwxKuEkQ72PHFGubn389rYvyn+HvrG9xciF/hm6fcwBulh60iuPHYbtD7p/oGgOysXvr9Q7Ab+Q2EznEI69DAworREwN+a+aglsgH84A/gP5QlEg/0M8QrlXTc7GVFoh42fKPFTzZAEWXAP5uFKIR4OdIdpsi5RBwo4A2ntFob+cfu5tdiT9Vn8P1bn7UhXh38tEYVt/BzkMK5RBQ4MqCAB5SXBw7p/ud+Jowyie3DDnsrU/EbdyQBH3glAc9GSDO8f9DJyhf6VXQ7ECIcIRjONou8f2zuxCGMHfYG/HpFkXW7Fj5eMdWmnSMWRD+YJic/cWCLtHHjxuDx56e1enkr81AhJNDHzoC/dFuvEB8OjsQS8KBev8c9aW/FihVuy4VCGGwSmBgU8ICC/rOvRAt1rQd0rkZtBMgSxO/+dzXz9Doz98HOhb1oHKj8Ll5U4wTYuRxUGXclabLzhLaHuWbHsGvXrthXhg47GH9DQB+glmBpZqVj4SAPW1pLaCQ+GeENGzb4XSnXhERTU5N/ZHZSFT5AySfNct6n4mYbcbZ+/Xp0YrEQduP6gh1e5hNChEJcwkeHZ2vWrAmyCqEVVV6ycJAdqqur3WRO59O+u6MjyMR0fajyCxfAH2nuC1SaVepV3AlTQ0NDWuLoGSBMvLOCUcdQS7A0QzJu4TBba7Fvbm62owO6yRgNKkEBEiatz9yecUGf5UWRhvhWld9UXIHNiC2kU1NLeRD1wS6zS2WvSh6HgRwKssnk5CduIfAdZHpNlrh06ZJwAJQ8dMSU+bVPpVnlAcSNtCnW6gULT1B4PKZ/AhislJlohGhnI40OByFnVNzkpAMs5P9cEgwTWYWF56iKy+P2gFAJ/7vFno55QAYhDZJNyArUEdn4d8u+O9OWBYiVk/RDxfWwgh/84feRgz35EZXfVTismAt59LHDHj9zRiYxPZtTYn6PCpO2QoVzFITRG1MZTgoZqV2lUYVyeN74Hw+78yoWhtEpAAAAAElFTkSuQmCC"
                                    ></van-image> </span
                                >&nbsp;{{ item.name }}
                            </div>
                            <div class="num">{{ item.totalPeople }}人参加·{{ item.totalPage }}篇帖子</div>
                        </div>
                        <div class="btn" @click="Quit">退出</div>
                    </div>
                </div>
            </van-tab>
            <van-tab title="我的圈子" v-model="myCircle">
                <van-empty
                    v-if="myCircle.length <= 0"
                    image="https://mhw.p2lfie.com/assets/ic_none.3df97c45.png"
                    description="空空的什么都没有"
                    title=""
                />
                <div v-else>
                    <div v-for="item in myCircle" :key="item.id">
                        <div class="circle">
                            <div class="cover">
                                <van-image :src="item.icon" fit="cover" alt="Image Alt Text" />
                            </div>
                            <div class="info">
                                <div class="name">
                                    <span>
                                        <van-image
                                            height="15"
                                            width="15"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC0AAAAtCAYAAAA6GuKaAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAALaADAAQAAAABAAAALQAAAABGqAVQAAAHNUlEQVRYCc2ZT2xVVRDGp4X+QcDStNiWFKWACRRoIq3YgCSNmLASMW4w6IZEYtQFuAGWLoysABMXRhMTIyYuNKjdSEyTJtpase2mNDShpdqW0gqNaQGhtBTnd96by3mXe19fy4P0S+ade8+dmfe9c+fMmXNejjw8ytXFKyq1Kqs8KdHrMZVhTzr0ulFlROWx42n9xiMqrSozKvfmIOhjhz1+HjkYvRMqkypzIRqnix/84Tdj5GSoWaB6h1WOqhT5Njk5OVJaWirl5eWydOlSKSwsdFJQUCCTk5Ny+/ZtJzdv3pSRkRG5du2a3LvHb0jBuN4dVzmpwg9Ji0xIE7NnVOp9TyUlJVJVVeXI5uXl+Y/SXk9NTTny/f39MjZGyKegTe9eU0kb87OR3qoOflSpVHFYvny5bNq0SSoqKqxr3u2VK1eku7tbrl+/7vsY0ptXVTr9Tv86Hek9qvityhIMCIMtW7bI2rVr3TV92QCh0tfXJ+fPn/fD5pb63qfyU9R3xJGuVeVfVRzh/Px82bZtm6xcuTLKR1b6rl69KufOnZM7d+6YP4i/qPLAiEeRJob/VHEhsWzZMtm+fbubZNr3SMFkbW1tlRs3btj3ECrPq6TE+CJ7mmzJEj+rVHPPCO/cuTNjwrzq6elplSmZmpqUmZkZ98pzc3MzCim+jyw0ODgod+/ehcKTKoz2aRXXoa2ER/qo9n3sHmgM79ixY9aQgCgTamhoSEZHRx1p7H0sXrxYysrKpLKy0k1g5kc6ECotLS1+jB9T/eNm41uT4PtUXB6uqamRdevWmV5ki/Ouri4ZHyfNZoaioiI3oWebH729vc530itfABmXI/3w+Eg7G1SEtFZbW5v2lfb09EhnZ6dbQLAxPKMz4bnNWojUiJTpvGUdGZ+wp7py6IIzMDDgfLMoxaG4uFguX75sE7NQ9VgMzqJvI00NcFEln876+vq0ebi9vd3FHbrgCc0xh94W2f+6yIZnE33+Z496Pv29yCdfiPxHTkhi9erVUldXZ7cPtIRdW1ub9ZNW8D5gI/2O3uzmKSvd5s06VDFghMmrht0NIk3fiexR61ICLAL0v6TT6cAbIt09GoN/JZQmJibSjjhvnBC8dcv9UriOqrTkJsxlb7J1S7Ndh1scXLhwIeg++KbWmV+LlD8VdKW9QA997Az4w28cKBU8OJ6QJi+/wANmNSknCmQJJp2BEf5U88wie1f2YJYWfeywN+AX/1GAj5dt4FkOaZZrF9tMjLjih/iyLEEMf3lq7oSNFMSxxw/AL/6jAB9vwsLzFUjXmnLcKPOcPGxg0mUaEmYTbrHHj8H3b33WhnjVQToo16iHo8CrY+EwkCWyAd8P/llBoxDiVQFp9nUOFPBRSCzN0+4ReTgqrUXZzdaHH/wBvoPaIwohXqtSSC9ZkgyykOXMTLDsS1WWd3W+P3Y5UQjxcqQ1iyZAwRIFn3RJcZTG/Pt8f15ZmuIwxKuEkQ72PHFGubn389rYvyn+HvrG9xciF/hm6fcwBulh60iuPHYbtD7p/oGgOysXvr9Q7Ab+Q2EznEI69DAworREwN+a+aglsgH84A/gP5QlEg/0M8QrlXTc7GVFoh42fKPFTzZAEWXAP5uFKIR4OdIdpsi5RBwo4A2ntFob+cfu5tdiT9Vn8P1bn7UhXh38tEYVt/BzkMK5RBQ4MqCAB5SXBw7p/ud+Jowyie3DDnsrU/EbdyQBH3glAc9GSDO8f9DJyhf6VXQ7ECIcIRjONou8f2zuxCGMHfYG/HpFkXW7Fj5eMdWmnSMWRD+YJic/cWCLtHHjxuDx56e1enkr81AhJNDHzoC/dFuvEB8OjsQS8KBev8c9aW/FihVuy4VCGGwSmBgU8ICC/rOvRAt1rQd0rkZtBMgSxO/+dzXz9Doz98HOhb1oHKj8Ll5U4wTYuRxUGXclabLzhLaHuWbHsGvXrthXhg47GH9DQB+glmBpZqVj4SAPW1pLaCQ+GeENGzb4XSnXhERTU5N/ZHZSFT5AySfNct6n4mYbcbZ+/Xp0YrEQduP6gh1e5hNChEJcwkeHZ2vWrAmyCqEVVV6ycJAdqqur3WRO59O+u6MjyMR0fajyCxfAH2nuC1SaVepV3AlTQ0NDWuLoGSBMvLOCUcdQS7A0QzJu4TBba7Fvbm62owO6yRgNKkEBEiatz9yecUGf5UWRhvhWld9UXIHNiC2kU1NLeRD1wS6zS2WvSh6HgRwKssnk5CduIfAdZHpNlrh06ZJwAJQ8dMSU+bVPpVnlAcSNtCnW6gULT1B4PKZ/AhislJlohGhnI40OByFnVNzkpAMs5P9cEgwTWYWF56iKy+P2gFAJ/7vFno55QAYhDZJNyArUEdn4d8u+O9OWBYiVk/RDxfWwgh/84feRgz35EZXfVTismAt59LHDHj9zRiYxPZtTYn6PCpO2QoVzFITRG1MZTgoZqV2lUYVyeN74Hw+78yoWhtEpAAAAAElFTkSuQmCC"
                                        ></van-image> </span
                                    >&nbsp;{{ item.name }}
                                </div>
                                <div class="num">{{ item.totalPeople }}人参加·{{ item.totalPage }}篇帖子</div>
                            </div>
                            <div class="btn" @click="Quit">退出</div>
                        </div>
                    </div>
                </div>
            </van-tab>
            <van-tab title="我加入的圈子" v-model="myJoinedCircle">
                <van-empty
                    v-if="myJoinedCircle.length <= 0"
                    image="https://mhw.p2lfie.com/assets/ic_none.3df97c45.png"
                    description="空空的什么都没有"
                    title=""
                />
                <div v-else>
                    <div v-for="item in myJoinedCircle" :key="item.id">
                        <div class="circle">
                            <div class="cover">
                                <van-image :src="item.icon" fit="cover" alt="Image Alt Text" />
                            </div>
                            <div class="info">
                                <div class="name">
                                    <span>
                                        <van-image
                                            height="15"
                                            width="15"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC0AAAAtCAYAAAA6GuKaAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAALaADAAQAAAABAAAALQAAAABGqAVQAAAHNUlEQVRYCc2ZT2xVVRDGp4X+QcDStNiWFKWACRRoIq3YgCSNmLASMW4w6IZEYtQFuAGWLoysABMXRhMTIyYuNKjdSEyTJtpase2mNDShpdqW0gqNaQGhtBTnd96by3mXe19fy4P0S+ade8+dmfe9c+fMmXNejjw8ytXFKyq1Kqs8KdHrMZVhTzr0ulFlROWx42n9xiMqrSozKvfmIOhjhz1+HjkYvRMqkypzIRqnix/84Tdj5GSoWaB6h1WOqhT5Njk5OVJaWirl5eWydOlSKSwsdFJQUCCTk5Ny+/ZtJzdv3pSRkRG5du2a3LvHb0jBuN4dVzmpwg9Ji0xIE7NnVOp9TyUlJVJVVeXI5uXl+Y/SXk9NTTny/f39MjZGyKegTe9eU0kb87OR3qoOflSpVHFYvny5bNq0SSoqKqxr3u2VK1eku7tbrl+/7vsY0ptXVTr9Tv86Hek9qvityhIMCIMtW7bI2rVr3TV92QCh0tfXJ+fPn/fD5pb63qfyU9R3xJGuVeVfVRzh/Px82bZtm6xcuTLKR1b6rl69KufOnZM7d+6YP4i/qPLAiEeRJob/VHEhsWzZMtm+fbubZNr3SMFkbW1tlRs3btj3ECrPq6TE+CJ7mmzJEj+rVHPPCO/cuTNjwrzq6elplSmZmpqUmZkZ98pzc3MzCim+jyw0ODgod+/ehcKTKoz2aRXXoa2ER/qo9n3sHmgM79ixY9aQgCgTamhoSEZHRx1p7H0sXrxYysrKpLKy0k1g5kc6ECotLS1+jB9T/eNm41uT4PtUXB6uqamRdevWmV5ki/Ouri4ZHyfNZoaioiI3oWebH729vc530itfABmXI/3w+Eg7G1SEtFZbW5v2lfb09EhnZ6dbQLAxPKMz4bnNWojUiJTpvGUdGZ+wp7py6IIzMDDgfLMoxaG4uFguX75sE7NQ9VgMzqJvI00NcFEln876+vq0ebi9vd3FHbrgCc0xh94W2f+6yIZnE33+Z496Pv29yCdfiPxHTkhi9erVUldXZ7cPtIRdW1ub9ZNW8D5gI/2O3uzmKSvd5s06VDFghMmrht0NIk3fiexR61ICLAL0v6TT6cAbIt09GoN/JZQmJibSjjhvnBC8dcv9UriOqrTkJsxlb7J1S7Ndh1scXLhwIeg++KbWmV+LlD8VdKW9QA997Az4w28cKBU8OJ6QJi+/wANmNSknCmQJJp2BEf5U88wie1f2YJYWfeywN+AX/1GAj5dt4FkOaZZrF9tMjLjih/iyLEEMf3lq7oSNFMSxxw/AL/6jAB9vwsLzFUjXmnLcKPOcPGxg0mUaEmYTbrHHj8H3b33WhnjVQToo16iHo8CrY+EwkCWyAd8P/llBoxDiVQFp9nUOFPBRSCzN0+4ReTgqrUXZzdaHH/wBvoPaIwohXqtSSC9ZkgyykOXMTLDsS1WWd3W+P3Y5UQjxcqQ1iyZAwRIFn3RJcZTG/Pt8f15ZmuIwxKuEkQ72PHFGubn389rYvyn+HvrG9xciF/hm6fcwBulh60iuPHYbtD7p/oGgOysXvr9Q7Ab+Q2EznEI69DAworREwN+a+aglsgH84A/gP5QlEg/0M8QrlXTc7GVFoh42fKPFTzZAEWXAP5uFKIR4OdIdpsi5RBwo4A2ntFob+cfu5tdiT9Vn8P1bn7UhXh38tEYVt/BzkMK5RBQ4MqCAB5SXBw7p/ud+Jowyie3DDnsrU/EbdyQBH3glAc9GSDO8f9DJyhf6VXQ7ECIcIRjONou8f2zuxCGMHfYG/HpFkXW7Fj5eMdWmnSMWRD+YJic/cWCLtHHjxuDx56e1enkr81AhJNDHzoC/dFuvEB8OjsQS8KBev8c9aW/FihVuy4VCGGwSmBgU8ICC/rOvRAt1rQd0rkZtBMgSxO/+dzXz9Doz98HOhb1oHKj8Ll5U4wTYuRxUGXclabLzhLaHuWbHsGvXrthXhg47GH9DQB+glmBpZqVj4SAPW1pLaCQ+GeENGzb4XSnXhERTU5N/ZHZSFT5AySfNct6n4mYbcbZ+/Xp0YrEQduP6gh1e5hNChEJcwkeHZ2vWrAmyCqEVVV6ycJAdqqur3WRO59O+u6MjyMR0fajyCxfAH2nuC1SaVepV3AlTQ0NDWuLoGSBMvLOCUcdQS7A0QzJu4TBba7Fvbm62owO6yRgNKkEBEiatz9yecUGf5UWRhvhWld9UXIHNiC2kU1NLeRD1wS6zS2WvSh6HgRwKssnk5CduIfAdZHpNlrh06ZJwAJQ8dMSU+bVPpVnlAcSNtCnW6gULT1B4PKZ/AhislJlohGhnI40OByFnVNzkpAMs5P9cEgwTWYWF56iKy+P2gFAJ/7vFno55QAYhDZJNyArUEdn4d8u+O9OWBYiVk/RDxfWwgh/84feRgz35EZXfVTismAt59LHDHj9zRiYxPZtTYn6PCpO2QoVzFITRG1MZTgoZqV2lUYVyeN74Hw+78yoWhtEpAAAAAElFTkSuQmCC"
                                        ></van-image> </span
                                    >&nbsp;{{ item.name }}
                                </div>
                                <div class="num">{{ item.totalPeople }}人参加·{{ item.totalPage }}篇帖子</div>
                            </div>
                            <div class="btn" @click="Quit">退出</div>
                        </div>
                    </div>
                </div>
            </van-tab>
        </van-tabs>
    </div>
</template>

<script>
import { Tab, Tabs, NavBar, Empty, Grid, GridItem, Image } from 'vant'
export default {
    name: 'userCircle',
    components: {
        [Tab.name]: Tab,
        [Tabs.name]: Tabs,
        [NavBar.name]: NavBar,
        [Empty.name]: Empty,
        [Grid.name]: Grid,
        [GridItem.name]: GridItem,
        [Image.name]: Image,
    },
    data() {
        return {
            activeTab: 0,
            dynamicList: [
                // {
                //     id:"123123",
                //     title:"小狗",
                //     icon:"https://mhw.p2lfie.com/assets/ic_none.3df97c45.png",
                //     name:"你好啊",
                //     totalPeople:123,
                //     totalPage:123,
                // }
            ],
            myCircle: [
                {
                    id: '123123',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '12312',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '12313',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '1233',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '123',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
            ],
            myJoinedCircle: [
                {
                    id: '123123',
                    title: '小狼狗',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你哈你哈',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '123124',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
                {
                    id: '123125',
                    title: '小',
                    icon: 'https://mhw.p2lfie.com/assets/ic_none.3df97c45.png',
                    name: '你好啊',
                    totalPeople: 123,
                    totalPage: 123,
                },
            ],
        }
    },
    methods: {
        onClickLeft() {
            console.log('123123')
        },
        Quit() {
            console.log(12312312)
        },
    },
    // 组件的逻辑部分
}
</script>

<style scoped>
::v-deep .van-tabs__content {
    transition: transform 0.3s ease-in-out !important;
}
::v-deep .van-empty__image img {
    display: inline-block;
    width: 81px;
    height: auto;
}

::v-deep .van-empty__image {
    display: inline-block;
    width: 81px;
    height: auto;
}

::v-deep .cover {
    width: 70px;
    height: 70px;
    border-radius: 6px;
    overflow: hidden;
    object-fit: cover;
}
::v-deep .btn {
    width: 62px;
    height: 28px;
    line-height: 28px;
    text-align: center;
    background: #f898c6;
    box-shadow: 0 3px 5px #4545450d;
    border-radius: 16px;
    font-family: FZLTZHUNHK--GBK1-0;
    font-size: 12px;
    color: #000;
    letter-spacing: 0.38px;
}

::v-deep .info {
    flex: 1;
    text-align: left;
    padding-left: 10px;
}

::v-deep .name {
    font-family: PingFangSC-Semibold;
    font-size: 16px;
    color: #333;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
}

::v-deep .circle {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}

::v-deep .num {
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #666;
    letter-spacing: 0;
    margin-top: 13px;
}
</style>
